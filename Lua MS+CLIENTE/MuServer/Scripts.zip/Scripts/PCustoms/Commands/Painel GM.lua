PainelGM = {}

function PainelGM.Init()
    if PainelGM_Config.Enabled then
        Commands.Register(PainelGM_Config.Command["Eng"], PainelGM.Command)
        Commands.Register(PainelGM_Config.Command["Por"], PainelGM.Command)
        Commands.Register(PainelGM_Config.Command["Spn"], PainelGM.Command)
        GameServerFunctions.GameServerProtocol(PainelGM.Protocol)
    end
end

function PainelGM.Command(aIndex)
    local player = User.new(aIndex)

    if player:getAuthority() <= 1 then return end

    local packetName = string.format("1-%s-%d", player:getName(), aIndex)
    CreatePacket(packetName, PainelGM_Config.Packet)
    SendPacket(packetName, aIndex)
    ClearPacket(packetName)
end

function PainelGM.Protocol(aIndex, Packet, PacketName)
    if Packet ~= PainelGM_Config.Packet then return end
    local player = User.new(aIndex)
    local name = player:getName()

    if PacketName == string.format("2-%s-%d",name, aIndex) then
        ClearPacket(PacketName)
        PainelGM.Command(aIndex)
        return true
    end

    if PacketName == string.format("3-%s-%d",name, aIndex) then
        local id = GetBytePacket(PacketName, -1)
        ClearPacket(PacketName)
        if id == 1 then
            Sorteio.SendOpenSorteio(aIndex)
        end
        return true
    end 
end

PainelGM.Init()

return PainelGM