NPCRuin = {}
NPCRuin.Monster = -1
NPCRuin.Delay = {}

function NPCRuin.Init()
    if NPCRuin_Config.Enabled then
        GameServerFunctions.NpcTalk(NPCRuin.NpcTalk)
		GameServerFunctions.MonsterReload(NPCRuin.ReloadNpc)
		NPCRuin.CriarNpc()
    end
end

function NPCRuin.ReloadNpc()
    NPCRuin.Monster = -1

    local m = NPCRuin_Config.Monster
	local index = AddMonster(m.Map)
    
	if index == -1
	then
		LogAdd(string.format("Erro ao criar npc ruin"))
		return
	end

	local monster = User.new(index)

	SetMonster(index, m.Class)
	SetMapMonster(index, m.Map, m.X, m.Y)
	monster:setDir(m.Dir)
	monster:setType(3)
    NPCRuin.Monster = index
end

function NPCRuin.CriarNpc()
    for aIndex = 0, 12000 do
        local monster = User.new(aIndex)
        if monster:getConnected() == 3 then
            local m = NPCRuin_Config.Monster
            if monster:getClass() == m.Class then
                if monster:getMapNumber() == m.Map then
                    if monster:getX() == m.X and monster:getY() == m.Y then
                        NPCRuin.Monster = aIndex
                        monster:setType(3)
                        monster:setDir(m.Dir)
                    end
                end
            end
        end
    end

    if NPCRuin.Monster == -1 then
        local m = NPCRuin_Config.Monster
	    local index = AddMonster(m.Map)
	    if index == -1
	    then
	    	LogAdd(string.format("Erro ao criar npc buff"))
	    	return
	    end
    
	    local monster = User.new(index)
    
	    SetMonster(index, m.Class)
	    SetMapMonster(index, m.Map, m.X, m.Y)
	    monster:setDir(m.Dir)
	    monster:setType(3)
        NPCRuin.Monster = index
    end
end

function NPCRuin.RemoveDelay(Player)
    NPCRuin.Delay[Player] = nil
end

function NPCRuin.NpcTalk(Monster, Player)
    if Monster == NPCRuin.Monster then
        if NPCRuin.Delay[Player] ~= nil then return 1 end
        NPCRuin.Delay[Player] = 1
        Timer.TimeOut(5, NPCRuin.RemoveDelay, Player)
        NPCRuin.Run(Player)
        return 1
    end

    return 0
end

function NPCRuin.Run(aIndex)
    local player = User.new(aIndex)
    local pInv = Inventory.new(aIndex)
    local playerInfo = {[0] = player:getAccountID(), [1] = player:getName()}
    local lang = player:getLanguage()
    local saldo = DataBase.GetValue(NPCRuin_Config.Coin.Table, NPCRuin_Config.Coin.Column, NPCRuin_Config.Coin.Where, playerInfo[NPCRuin_Config.Coin.IdType])

    if saldo < NPCRuin_Config.Coin.Amount then
        ChatTargetSend(NPCRuin.Monster, string.format(NPCRuin_Config.Message[lang][1], NPCRuin_Config.Coin.Amount, NPCRuin_Config.Coin.Name), aIndex)
        return
    end

    local countItens = 0
    local ItemFound = {}

    for slot = 12, 75 do
        if pInv:isItem(slot) ~= 0 then
            countItens = countItens + 1
            ItemFound = {Index = pInv:getIndex(slot), Durability = pInv:getDurability(slot)}
        end
    end

    if countItens > 1 then
        ChatTargetSend(NPCRuin.Monster, string.format(NPCRuin_Config.Message[lang][2]), aIndex)
        return
    end

    if countItens == 0 then return end

    local enabled = false
    for i in ipairs(NPCRuin_Config.Itens) do
        if NPCRuin_Config.Itens[i] == ItemFound.Index then
            enabled = true
        end
    end

    if not enabled then
        ChatTargetSend(NPCRuin.Monster, string.format(NPCRuin_Config.Message[lang][4]), aIndex)
        return
    end

    DeleteItemCount(aIndex, ItemFound.Index, -1, 1)

    DataBaseAsync.SetDecreaseValue(NPCRuin_Config.Coin.Table, NPCRuin_Config.Coin.Column, NPCRuin_Config.Coin.Amount, NPCRuin_Config.Coin.Where, playerInfo[NPCRuin_Config.Coin.IdType])

    ItemSerialCreateComplete(aIndex, 236,0,0,ItemFound.Index, 0,ItemFound.Durability,0,0,0,0,0,0,0)
    ChatTargetSend(NPCRuin.Monster, string.format(NPCRuin_Config.Message[lang][3]), aIndex)
end

NPCRuin.Init()

return NPCRuin