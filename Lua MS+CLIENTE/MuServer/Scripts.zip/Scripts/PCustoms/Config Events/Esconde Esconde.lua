EscEsc_Ativado = true

EscEsc_Agenda = {

	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 03},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 05},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 07},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 10},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 12},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 15},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 17},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 20},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 22},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 25},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 27},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 31},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 33},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 37},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 40},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 42},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 45},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 47},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 50},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 52},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 55},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 12, Minuto = 57},

	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 03},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 05},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 07},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 10},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 12},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 15},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 17},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 20},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 22},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 25},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 27},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 31},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 33},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 37},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 40},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 42},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 45},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 47},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 50},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 52},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 55},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 15, Minuto = 57},


	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 03},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 05},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 07},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 10},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 12},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 15},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 17},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 20},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 22},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 25},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 27},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 31},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 33},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 37},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 40},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 42},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 45},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 47},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 50},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 52},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 55},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 17, Minuto = 57},

	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 03},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 05},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 07},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 10},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 12},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 15},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 17},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 20},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 22},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 25},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 27},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 31},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 33},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 37},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 40},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 42},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 45},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 47},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 50},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 52},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 55},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 19, Minuto = 57},

}

EscEsc_Mapas = {
{ Nome = "Lorencia",	Mapa = 0,	X1 = 157,	X2 = 136,	Y1 = 118,	Y2 = 139},

}

EscEsc_NpcClass = 249

EscEsc_CommandOpen = "/abriresc"
EscEsc_CommandCancel = "/fimesc"

EscEsc_TempoMaximo = 1 -- Tempo m�ximo em minutos para do evento ser cancelado caso n�o tenha ganhadores

EscEsc_PremioMoeda = {Nome = "CASH", Quantidade = 20, Coluna = "WCoinC"}
EscEsc_PremioPonto = {Quantidade = 0, Coluna = "tradewins"}
EscEsc_PremioPonto2 = {Quantidade = 0, Coluna = "eventostotais"}

EscEsc_PremioReward = GET_ITEM(14, 123)
