Race_Config = {
    Enabled = true,

    Command = {
        ["Eng"] = {
            Open = "/abrirlabirinto",
            Go = "/labirinto",
            Cancel = "/cancelarlabirinto"
        },

        ["Por"] = {
            Open = "/abrirlabirinto",
            Go = "/labirinto",
            Cancel = "/cancelarlabirinto"
        },

        ["Spn"] = {
            Open = "/abrirlabirinto",
            Go = "/labirinto",
            Cancel = "/cancelarlabirinto"
        }
    },

    Cron = {
        --{DayOfMonth = -1, DayOfWeek = -1, Hour = 22, Minute = 50},
    },

    TimeAnnounce = 1, -- o tempo para anunciar o evento acontecer� em minutos, 0 para come�ar sem demora | 82 239 235

    TimeOpen = 30, -- time in seconds the players can enter the event

    Area = {
        Total = {Map  = 82, X1 = 20, X2 = 251, Y1 = 20, Y2 = 251},
        Wait = {Map  = 82, X = 232, Y = 130},
        Start = {Map = 82, X = 239, Y = 235} 
    },

    Npc = {Class = 249, Map = 82, X = 137, Y = 251, Dir = 2},

    EventTimeOut = 2, -- tempo em minutos que o evento terminar� se n�o houver vencedores

    ResetSkills = false, -- remover habilidades dos jogadores ao entrar no evento (impedir o uso ou teletransporte)

    Winners = 1, -- quantidade de vencedores

    PrizeItem = {
        [1] = {
            {Section = 14, Index = 57, Level = 0, Skill = 0, Luck = 0, Option = 0, Exc = 0, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, ItemTime = 0},
        },
        [2] = {
            {Section = 14, Index = 57, Level = 0, Skill = 0, Luck = 0, Option = 0, Exc = 0, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, ItemTime = 0},
        },
        [3] = {
            {Section = 14, Index = 57, Level = 0, Skill = 0, Luck = 0, Option = 0, Exc = 0, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, ItemTime = 0},
        },
		
    },

    PrizeCoin = {
        [1] = {
			{Name = "CASH", Amount = 100, Table = "CashShopData", Column = "WCoinC", Where = "AccountID", IdType = 0},
            {Name = "mtmta", Amount = 1, Table = "Character", Column = "matamata", Where = "name", IdType = 1},

        },
        [2] = {
			{Name = "CASH", Amount = 30, Table = "CashShopData", Column = "WCoinC", Where = "AccountID", IdType = 0},
            {Name = "mtmta", Amount = 1, Table = "Character", Column = "matamata", Where = "name", IdType = 1},

        },
        [3] = {
			{Name = "CASH", Amount = 20, Table = "CashShopData", Column = "WCoinC", Where = "AccountID", IdType = 0},
            {Name = "mtmta", Amount = 1, Table = "Character", Column = "matamata", Where = "name", IdType = 1},

        },		
		
    },

    PrizeZen = {
        --[1] = 0,
    },

    ReturnSkills = { -- habilidades para adicionar ao jogador quando o evento terminar se ResetSkill = true
        [0] = {

            {Section = 12, ID = 8},
            {Section = 12, ID = 9},
            {Section = 12, ID = 10},
            {Section = 12, ID = 11},
            {Section = 12, ID = 12},
            {Section = 12, ID = 13},
            {Section = 12, ID = 14},
        },
    
        [1] = {

            {Section = 12, ID = 8},
            {Section = 12, ID = 9},
            {Section = 12, ID = 10},
            {Section = 12, ID = 11},
            {Section = 12, ID = 12},
            {Section = 12, ID = 13},
            {Section = 12, ID = 14},
        },
    
        [2] = {

            {Section = 12, ID = 8},
            {Section = 12, ID = 9},
            {Section = 12, ID = 10},
            {Section = 12, ID = 11},
            {Section = 12, ID = 12},
            {Section = 12, ID = 13},
            {Section = 12, ID = 14},
        },
    
        [3] = {

            {Section = 12, ID = 8},
            {Section = 12, ID = 9},
            {Section = 12, ID = 10},
            {Section = 12, ID = 11},
            {Section = 12, ID = 12},
            {Section = 12, ID = 13},
            {Section = 12, ID = 14},
        },
    
        [4] = {

            {Section = 12, ID = 8},
            {Section = 12, ID = 9},
            {Section = 12, ID = 10},
            {Section = 12, ID = 11},
            {Section = 12, ID = 12},
            {Section = 12, ID = 13},
            {Section = 12, ID = 14},
        },
    
        [5] = {

            {Section = 12, ID = 8},
            {Section = 12, ID = 9},
            {Section = 12, ID = 10},
            {Section = 12, ID = 11},
            {Section = 12, ID = 12},
            {Section = 12, ID = 13},
            {Section = 12, ID = 14},
        },
    
        [6] = {

            {Section = 12, ID = 8},
            {Section = 12, ID = 9},
            {Section = 12, ID = 10},
            {Section = 12, ID = 11},
            {Section = 12, ID = 12},
            {Section = 12, ID = 13},
            {Section = 12, ID = 14},
        },
    },

    Message = {
        ["Eng"] = {
            [1] = "J� existe uma labirinto aberta, use %s para cancelar",
            [2] = "Tempo m�nimo 5 segundos, use %s <tempo>",
            [3] = "Evento labirinto foi aberto",
            [4] = ">>>>>>   Evento labirinto   <<<<<<",
            [5] = "%s fecha em %d segundos",
            [6] = "%s fecha em %d segundo",
            [7] = "N�o existe uma labirinto aberta, use %s para abrir",
            [8] = "Evento labirinto foi cancelado",
            [9] = "N�o h� evento labirinto aberto no momento",
            [10] = "Voc� foi movido ao evento",
            [11] = "Seu invent�rio precisa estar vazio para entrar no evento",
            [12] = "Sua loja pessoal precisa estar vazia para entrar no evento",
            [13] = "==============================",
            [14] = "Evento labirinto Iniciado",
            [15] = "Voc� saiu do evento",
            [16] = " Parab�ns, voc� foi o %d� ganhador ",
            [17] = " Voc� ser� movido para lorencia",
            [18] = "%s foi o vencedor da labirinto",
            [19] = " Voc� recebeu %d %s",
            [20] = "Evento labirinto foi finalizado",
            [21] = "Evento labirinto inicia em %d minuto(s)",
        },

        ["Por"] = {
            [1] = "J� existe uma labirinto aberta, use %s para cancelar",
            [2] = "Tempo m�nimo 5 segundos, use %s <tempo>",
            [3] = "Evento labirinto foi aberto",
            [4] = ">>>>>>   Evento labirinto   <<<<<<",
            [5] = "%s fecha em %d segundos",
            [6] = "%s fecha em %d segundo",
            [7] = "N�o existe uma labirinto aberta, use %s para abrir",
            [8] = "Evento labirinto foi cancelado",
            [9] = "N�o h� evento labirinto aberto no momento",
            [10] = "Voc� foi movido ao evento",
            [11] = "Seu invent�rio precisa estar vazio para entrar no evento",
            [12] = "Sua loja pessoal precisa estar vazia para entrar no evento",
            [13] = "==============================",
            [14] = "Evento labirinto Iniciado",
            [15] = "Voc� saiu do evento",
            [16] = " Parab�ns, voc� foi o %d� ganhador ",
            [17] = " Voc� ser� movido para lorencia",
            [18] = "%s foi o vencedor da labirinto",
            [19] = " Voc� recebeu %d %s",
            [20] = "Evento labirinto foi finalizado",
            [21] = "Evento labirinto inicia em %d minuto(s)",
        },

        ["Spn"] = {
            [1] = "J� existe uma labirinto aberta, use %s para cancelar",
            [2] = "Tempo m�nimo 5 segundos, use %s <tempo>",
            [3] = "Evento labirinto foi aberto",
            [4] = ">>>>>>   Evento labirinto   <<<<<<",
            [5] = "%s fecha em %d segundos",
            [6] = "%s fecha em %d segundo",
            [7] = "N�o existe uma labirinto aberta, use %s para abrir",
            [8] = "Evento labirinto foi cancelado",
            [9] = "N�o h� evento labirinto aberto no momento",
            [10] = "Voc� foi movido ao evento",
            [11] = "Seu invent�rio precisa estar vazio para entrar no evento",
            [12] = "Sua loja pessoal precisa estar vazia para entrar no evento",
            [13] = "==============================",
            [14] = "Evento labirinto Iniciado",
            [15] = "Voc� saiu do evento",
            [16] = " Parab�ns, voc� foi o %d� ganhador ",
            [17] = " Voc� ser� movido para lorencia",
            [18] = "%s foi o vencedor da labirinto",
            [19] = " Voc� recebeu %d %s",
            [20] = "Evento labirinto foi finalizado",
            [21] = "Evento labirinto inicia em %d minuto(s)",
        },
    }
}

return Race_Config