ItemAttributes_Config = {
    Enabled = true,

    Itens = {


	     -----------------------------------------------------------------------------------------------------
		 --                                          SWORDS                                                --
	     -----------------------------------------------------------------------------------------------------
			
        {Slot = 0, Section = 0,  Index = 90	,  Level = -1, Attribute = 1},  -- "Death Relic Sword  [RL]"			
        {Slot = 0, Section = 0,  Index = 91	,  Level = -1, Attribute = 2},  -- "Death Relic Knifer  [RL]"			
        {Slot = 0, Section = 0,  Index = 92	,  Level = -1, Attribute = 3},  -- "Death Relic Mace  [RL]"		
        {Slot = 0, Section = 0,  Index = 93	,  Level = -1, Attribute = 4},  -- "Death Relic Spear  [RL]"			
        {Slot = 0, Section = 0,  Index = 117,  Level = -1, Attribute = 5},  -- "Blood Dark [RL]"		          
        {Slot = 0, Section = 0,  Index = 118,  Level = -1, Attribute = 6},  -- "Blood Dark Scepter [RL]"			

        {Slot = 3, Section = 8,  Index = 270,  Level = -1, Attribute = 7},	    --
		
		{Slot = 3, Section = 8,  Index = 249,  Level = -1, Attribute = 8},    -- "Death Relic Helm [C]"	    		
        {Slot = 3, Section = 8,  Index = 250,  Level = -1, Attribute = 9},    -- "Death Relic Helm [F][C]"
		
		--angelic
        {Slot = 0, Section = 0,  Index = 107,  Level = -1, Attribute = 10},    --		
        {Slot = 0, Section = 0,  Index = 108,  Level = -1, Attribute = 11},    --		
        {Slot = 3, Section = 8,  Index = 262,  Level = -1, Attribute = 12},    --
        {Slot = 3, Section = 8,  Index = 263,  Level = -1, Attribute = 13},    --

		--HORUS
        {Slot = 0, Section = 0,  Index = 112,  Level = -1, Attribute = 14},    --		
        {Slot = 0, Section = 0,  Index = 113,  Level = -1, Attribute = 15},    --		
        {Slot = 3, Section = 8,  Index = 266,  Level = -1, Attribute = 16},    --

		--RADIENCE
        {Slot = 0, Section = 0,  Index = 105,  Level = -1, Attribute = 17},    --		
        {Slot = 0, Section = 0,  Index = 106,  Level = -1, Attribute = 18},    --		
        {Slot = 3, Section = 8,  Index = 258,  Level = -1, Attribute = 19},    --

		--/FREE ALL
        {Slot = 0, Section = 0,  Index = 132,  Level = -1, Attribute = 20},    --		
        {Slot = 0, Section = 0,  Index = 133,  Level = -1, Attribute = 21},    --		
        {Slot = 3, Section = 8,  Index = 278,  Level = -1, Attribute = 22},    --
		
		--ALL ANGEL BLACK
        {Slot = 0, Section = 0,  Index = 97,  Level = -1, Attribute = 23},    -- SWORD		
        {Slot = 0, Section = 0,  Index = 98,  Level = -1, Attribute = 24},    -- SWORD		
        {Slot = 0, Section = 0,  Index = 99,  Level = -1, Attribute = 25},    -- SWORD
        {Slot = 3, Section = 8,  Index = 256, Level = -1, Attribute = 26},    -- SET

		--ALL NATAL
        {Slot = 0, Section = 0,  Index = 75,  Level = -1, Attribute = 27},    -- SWORD		
        {Slot = 0, Section = 0,  Index = 76,  Level = -1, Attribute = 28},    -- SWORD		
        {Slot = 0, Section = 0,  Index = 77,  Level = -1, Attribute = 29},    -- SWORD
        {Slot = 3, Section = 8,  Index = 237, Level = -1, Attribute = 30},    -- SET

		--ALL reaper
        {Slot = 0, Section = 0,  Index = 114, Level = -1, Attribute = 31},    -- SWORD		
        {Slot = 0, Section = 0,  Index = 115, Level = -1, Attribute = 32},    -- SWORD		
        {Slot = 0, Section = 0,  Index = 116, Level = -1, Attribute = 33},    -- SWORD
        {Slot = 3, Section = 8,  Index = 267, Level = -1, Attribute = 34},    -- SET

		--ALL APOLLO
        {Slot = 0, Section = 0,  Index = 78,  Level = -1, Attribute = 35},    -- SWORD		
        {Slot = 0, Section = 2,  Index = 72,  Level = -1, Attribute = 36},    -- SWORD		
        {Slot = 0, Section = 5,  Index = 57,  Level = -1, Attribute = 37},    -- STAFF
        {Slot = 3, Section = 8,  Index = 239, Level = -1, Attribute = 38},    -- SET
        {Slot = 3, Section = 8,  Index = 242, Level = -1, Attribute = 39},    -- SET

		--ALL MYSTIC
        {Slot = 0, Section = 0,  Index = 100,  Level = -1, Attribute = 40},    -- SWORD		
        {Slot = 0, Section = 0,  Index = 101,  Level = -1, Attribute = 41},    -- SWORD
        {Slot = 0, Section = 0,  Index = 102,  Level = -1, Attribute = 42},    -- SWORD
        {Slot = 0, Section = 0,  Index = 103,  Level = -1, Attribute = 43},    -- SWORD
        {Slot = 0, Section = 0,  Index = 104,  Level = -1, Attribute = 44},    -- SWORD
		
        {Slot = 0, Section = 5,  Index = 63,  Level = -1, Attribute = 45},    -- STAFF

        {Slot = 3, Section = 8,  Index = 257, Level = -1, Attribute = 46},    -- SET
		
    },                                                                         


    Attributes = {                                                             
 
-------------------------------------------------------------------            
--                       SWORDS   1 / 400                        --            
-------------------------------------------------------------------            
  
	   [1]   =    {DefenseMultiply = 0.00,  DefenseAdd = 0,  BlockSuccessMultiply = 1.10,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1500,    MagicDamageMultiply =  1.10,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.10, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.10, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [2]   =    {DefenseMultiply = 0.00,  DefenseAdd = 0,  BlockSuccessMultiply = 1.10,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1500,    MagicDamageMultiply =  1.10,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.10, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.10, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [3]   =    {DefenseMultiply = 0.00,  DefenseAdd = 0,  BlockSuccessMultiply = 1.10,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1500,    MagicDamageMultiply =  1.10,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.10, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.10, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [4]   =    {DefenseMultiply = 0.00,  DefenseAdd = 0,  BlockSuccessMultiply = 1.10,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1500,    MagicDamageMultiply =  1.10,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.10, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.10, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [5]   =    {DefenseMultiply = 0.00,  DefenseAdd = 0,  BlockSuccessMultiply = 1.10,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1500,    MagicDamageMultiply =  1.10,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.10, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.10, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [6]   =    {DefenseMultiply = 0.00,  DefenseAdd = 0,  BlockSuccessMultiply = 1.10,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1500,    MagicDamageMultiply =  1.10,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.10, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.10, MagicSpeedAdd = 0},    -- Sword Of Heat Red

	   [7]   =    {DefenseMultiply = 0.0,  DefenseAdd = 500,  BlockSuccessMultiply = 0.00,   BlockSuccessAdd = 0, LifeAdd = 50000,  ManaAdd = 0, DamageMultiply = 0.0, DamageAdd = 0,    MagicDamageMultiply =  0.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 0.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 0.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [8]   =    {DefenseMultiply = 0.0,  DefenseAdd = 500,  BlockSuccessMultiply = 0.00,   BlockSuccessAdd = 0, LifeAdd = 50000,  ManaAdd = 0, DamageMultiply = 0.0, DamageAdd = 0,    MagicDamageMultiply =  0.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 0.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 0.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [9]   =    {DefenseMultiply = 0.0,  DefenseAdd = 500,  BlockSuccessMultiply = 0.00,   BlockSuccessAdd = 0, LifeAdd = 50000,  ManaAdd = 0, DamageMultiply = 0.0, DamageAdd = 0,    MagicDamageMultiply =  0.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 0.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 0.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red

	--ALL ANGELIC
	   [10]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1000,    MagicDamageMultiply =  1.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [11]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1000,    MagicDamageMultiply =  1.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [12]  =    {DefenseMultiply = 0.0,   DefenseAdd = 350, BlockSuccessMultiply = 0.00,   BlockSuccessAdd = 0, LifeAdd = 8000,  ManaAdd = 0, DamageMultiply = 0.0, DamageAdd = 0,    	MagicDamageMultiply =  0.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 0.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 0.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [13]  =    {DefenseMultiply = 0.0,   DefenseAdd = 350, BlockSuccessMultiply = 0.00,   BlockSuccessAdd = 0, LifeAdd = 8000,  ManaAdd = 0, DamageMultiply = 0.0, DamageAdd = 0,    	MagicDamageMultiply =  0.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 0.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 0.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red

	--ALL HORUS
	   [14]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1000,    MagicDamageMultiply =  1.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [15]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1000,    MagicDamageMultiply =  1.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [16]  =    {DefenseMultiply = 0.0,   DefenseAdd = 350, BlockSuccessMultiply = 0.00,   BlockSuccessAdd = 0, LifeAdd = 8000,  ManaAdd = 0, DamageMultiply = 0.0, DamageAdd = 0,    	MagicDamageMultiply =  0.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 0.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 0.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red

	--ALL RADIANCE
	   [17]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1000,    MagicDamageMultiply =  1.0,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [18]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1000,    MagicDamageMultiply =  1.0,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [19]  =    {DefenseMultiply = 0.0,   DefenseAdd = 350, BlockSuccessMultiply = 0.00,   BlockSuccessAdd = 0, LifeAdd = 8000,  ManaAdd = 0, DamageMultiply = 0.0, DamageAdd = 0,    	MagicDamageMultiply =  0.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 0.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 0.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red


	--/FREE ALL
	   [20]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1000,    MagicDamageMultiply =  1.10,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.10, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [21]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1000,    MagicDamageMultiply =  1.10,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.10, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [22]  =    {DefenseMultiply = 0.0,   DefenseAdd = 600, BlockSuccessMultiply = 0.00,   BlockSuccessAdd = 0, LifeAdd = 40000, ManaAdd = 0, DamageMultiply = 0.0, DamageAdd = 0,    	MagicDamageMultiply =  0.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 0.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 0.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red

	-- ALL BLACK ANGEL
	   [23]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.0, DamageAdd = 1000,    MagicDamageMultiply =  1.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [24]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.0, DamageAdd = 1000,    MagicDamageMultiply =  1.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [25]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.0, DamageAdd = 1000,    MagicDamageMultiply =  1.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [26]  =    {DefenseMultiply = 0.0,   DefenseAdd = 350, BlockSuccessMultiply = 0.00,   BlockSuccessAdd = 0, LifeAdd = 8000,  ManaAdd = 0, DamageMultiply = 0.0, DamageAdd = 0,    	MagicDamageMultiply =  0.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 0.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 0.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red

	-- ALL NATAL
	   [27]   =    {DefenseMultiply = 0.00,  DefenseAdd = 0,  BlockSuccessMultiply = 1.10,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1500,    MagicDamageMultiply =  1.10,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.10, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.10, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [28]   =    {DefenseMultiply = 0.00,  DefenseAdd = 0,  BlockSuccessMultiply = 1.10,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1500,    MagicDamageMultiply =  1.10,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.10, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.10, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [29]   =    {DefenseMultiply = 0.00,  DefenseAdd = 0,  BlockSuccessMultiply = 1.10,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.1, DamageAdd = 1500,    MagicDamageMultiply =  1.10,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.10, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.10, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [30]   =    {DefenseMultiply = 0.0,  DefenseAdd = 500, BlockSuccessMultiply = 0.00,   BlockSuccessAdd = 0, LifeAdd = 40000, ManaAdd = 0, DamageMultiply = 0.0, DamageAdd = 0,    MagicDamageMultiply =  0.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 0.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 0.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red

	-- ALL REAPER
	   [31]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.0, DamageAdd = 1000,    MagicDamageMultiply =  1.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [32]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.0, DamageAdd = 1000,    MagicDamageMultiply =  1.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [33]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.0, DamageAdd = 1000,    MagicDamageMultiply =  1.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [34]  =    {DefenseMultiply = 0.0,   DefenseAdd = 350, BlockSuccessMultiply = 0.00,   BlockSuccessAdd = 0, LifeAdd = 10000,  ManaAdd = 0, DamageMultiply = 0.0, DamageAdd = 0,    	MagicDamageMultiply =  0.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 0.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 0.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red

	-- ALL APOLO
	   [35]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.0, DamageAdd = 1000,    MagicDamageMultiply =  1.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [36]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.0, DamageAdd = 1000,    MagicDamageMultiply =  1.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [37]  =    {DefenseMultiply = 0.00,  DefenseAdd = 0,   BlockSuccessMultiply = 1.00,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.0, DamageAdd = 1000,    MagicDamageMultiply =  1.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [38]  =    {DefenseMultiply = 0.0,   DefenseAdd = 350, BlockSuccessMultiply = 0.00,   BlockSuccessAdd = 0, LifeAdd = 10000,  ManaAdd = 0, DamageMultiply = 0.0, DamageAdd = 0,    	MagicDamageMultiply =  0.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 0.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 0.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [39]  =    {DefenseMultiply = 0.0,   DefenseAdd = 350, BlockSuccessMultiply = 0.00,   BlockSuccessAdd = 0, LifeAdd = 15000,  ManaAdd = 0, DamageMultiply = 0.0, DamageAdd = 0,    	MagicDamageMultiply =  0.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 0.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 0.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	
	-- ALL MYSTIC
	   [40]   =    {DefenseMultiply = 0.00,  DefenseAdd = 0,  BlockSuccessMultiply = 1.20,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.2, DamageAdd = 2000,    MagicDamageMultiply =  1.20,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.20, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.20, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [41]   =    {DefenseMultiply = 0.00,  DefenseAdd = 0,  BlockSuccessMultiply = 1.20,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.2, DamageAdd = 2000,    MagicDamageMultiply =  1.20,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.20, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.20, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [42]   =    {DefenseMultiply = 0.00,  DefenseAdd = 0,  BlockSuccessMultiply = 1.20,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.2, DamageAdd = 2000,    MagicDamageMultiply =  1.20,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.20, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.20, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [43]   =    {DefenseMultiply = 0.00,  DefenseAdd = 0,  BlockSuccessMultiply = 1.20,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.2, DamageAdd = 2000,    MagicDamageMultiply =  1.20,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.20, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.20, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [44]   =    {DefenseMultiply = 0.00,  DefenseAdd = 0,  BlockSuccessMultiply = 1.20,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.2, DamageAdd = 2000,    MagicDamageMultiply =  1.20,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.20, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.20, MagicSpeedAdd = 0},    -- Sword Of Heat Red
	   [45]   =    {DefenseMultiply = 0.00,  DefenseAdd = 0,  BlockSuccessMultiply = 1.20,   BlockSuccessAdd = 0, LifeAdd = 0,     ManaAdd = 0, DamageMultiply = 1.2, DamageAdd = 2000,    MagicDamageMultiply =  1.20,  MagicDamageAdd = 0,  AttackSpeedMultiply = 1.20, AttackSpeedAdd = 0, MagicSpeedMultiply = 1.20, MagicSpeedAdd = 0},    -- Sword Of Heat Red

	   [46]   =    {DefenseMultiply = 0.0,  DefenseAdd = 600,  BlockSuccessMultiply = 0.00,   BlockSuccessAdd = 0, LifeAdd = 90000,  ManaAdd = 0, DamageMultiply = 0.0, DamageAdd = 0,    MagicDamageMultiply =  0.00,  MagicDamageAdd = 0,  AttackSpeedMultiply = 0.00, AttackSpeedAdd = 0, MagicSpeedMultiply = 0.00, MagicSpeedAdd = 0},    -- Sword Of Heat Red


	},                                                                         


}                                                                              
  
return ItemAttributes_Config                                                   