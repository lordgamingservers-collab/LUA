

Taxa_Config = {
	-- true ativa o sistema, false desativa
	Ativado = true,

	Moeda = {
		Tabela = "MEMB_INFO",
		Coluna = "Coin1",
		Where = "memb___id",
		Nome = "Dolar",
		Tipo = 0
	},

	Itens = {

		
		[GET_ITEM(0, 100)] = 1000000,
		[GET_ITEM(0, 101)] = 1000000,
		[GET_ITEM(0, 102)] = 1000000,
		[GET_ITEM(0, 103)] = 1000000,
		[GET_ITEM(0, 104)] = 1000000,
		[GET_ITEM(5, 63)]  = 1000000,
		[GET_ITEM(6, 237)] = 1000000,

		[GET_ITEM(7,  257)] = 1000000,
		[GET_ITEM(8,  257)] = 1000000,
		[GET_ITEM(9,  257)] = 1000000,
		[GET_ITEM(10, 257)] = 1000000,
		[GET_ITEM(11, 257)] = 1000000,

		[GET_ITEM(12, 267)] = 1000000,
		[GET_ITEM(12, 268)] = 1000000,

		[GET_ITEM(15, 413)] = 1000000,
		[GET_ITEM(15, 414)] = 1000000,
		[GET_ITEM(15, 415)] = 1000000,
		[GET_ITEM(15, 416)] = 1000000,

		[GET_ITEM(13, 264)] = 1000000,
		[GET_ITEM(13, 321)] = 1000000,
		[GET_ITEM(13, 322)] = 1000000,
		[GET_ITEM(13, 323)] = 1000000,
		[GET_ITEM(13, 324)] = 1000000,

		[GET_ITEM(7,  48)] = 1000000,
		[GET_ITEM(8,  48)] = 1000000,
		[GET_ITEM(9,  48)] = 1000000,
		[GET_ITEM(10, 48)] = 1000000,
		[GET_ITEM(11, 48)] = 1000000,
		
		[GET_ITEM(7,  33)] = 1000000,
		[GET_ITEM(8,  33)] = 1000000,
		[GET_ITEM(9,  33)] = 1000000,
		[GET_ITEM(10, 33)] = 1000000,
		[GET_ITEM(11, 33)] = 1000000,

	},

	CharIsento = {
		"ViNi",

	},


	Message = {
		["Por"] = {
			[1] = "N�o � permitido item Bloqueado na lojinha",
			[2] = "Negocia��o isenta de taxa!",
			[3] = "N�o � permitido o Comercio desse Item",
			[4] = "Voc� pagou %d %s para realizar a troca",
		},

		["Spn"] = {
			[1] = "N�o � permitido item Bloqueado na lojinha",
			[2] = "Negocia��o isenta de taxa!",
			[3] = "N�o � permitido o Comercio desse Item",
			[4] = "Voc� pagou %d %s para realizar a troca",
		},

		["Eng"] = {
			[1] = "N�o � permitido item Bloqueado na lojinha",
			[2] = "Negocia��o isenta de taxa!",
			[3] = "N�o � permitido o Comercio desse Item",
			[4] = "Voc� pagou %d %s para realizar a troca",
		},
	}
}

return Taxa_Config