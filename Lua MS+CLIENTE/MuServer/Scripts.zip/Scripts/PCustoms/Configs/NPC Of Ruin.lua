NPCRuin_Config = {
    Enabled = true,

    Monster = {
        Class = 248,
        Map = 0,
        X = 139,
        Y = 136,
        Dir = 3
    },

    Itens = {
        GET_ITEM(0,1),
        GET_ITEM(0,20),
    },

    Coin = {
        Name = "AxionGold",
        Amount = 10,
        Table = "MEMB_INFO",
        Column = "AxionGold",
        Where = "memb___id",
        IdType = 0
    },

    Message = {
        ["Eng"] = {
            [1] = "Você precisa de %d %s ",
            [2] = "Seu inventário deve conter somente 1 item ",
            [3] = "Seu item foi arruinado! ",
            [4] = "Este item não pode ser arruinado "
        },
        ["Por"] = {
            [1] = "Você precisa de %d %s ",
            [2] = "Seu inventário deve conter somente 1 item ",
            [3] = "Seu item foi arruinado! ",
            [4] = "Este item não pode ser arruinado "
        },
        ["Spn"] = {
            [1] = "Você precisa de %d %s ",
            [2] = "Seu inventário deve conter somente 1 item ",
            [3] = "Seu item foi arruinado! ",
            [4] = "Este item não pode ser arruinado "
        },
    }
}

return NPCRuin_Config