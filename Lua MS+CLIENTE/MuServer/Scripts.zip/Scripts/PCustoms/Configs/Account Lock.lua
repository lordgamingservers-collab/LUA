AccountLock_Config = {
    Enabled = true,

    Accounts = {
  
				["admin"] = {
            Trade = false,
            Drop = false,
            Sell = false,
            PersonalStore = false,
        },

				["gm01"] = {
            Trade = false,
            Drop = false,
            Sell = false,
            PersonalStore = false,
        },

				["gm02"] = {
            Trade = false,
            Drop = false,
            Sell = false,
            PersonalStore = false,
        },

				["gm03"] = {
            Trade = false,
            Drop = false,
            Sell = false,
            PersonalStore = false,
        },

				["gm04"] = {
            Trade = false,
            Drop = false,
            Sell = false,
            PersonalStore = false,
        },

				["gm05"] = {
            Trade = false,
            Drop = false,
            Sell = false,
            PersonalStore = false,
        },

				["staff"] = {
            Trade = false,
            Drop = false,
            Sell = false,
            PersonalStore = false,
        },

        ["staff1"] = {
            Trade = false,
            Drop = false,
            Sell = false,
            PersonalStore = false,
        },
		
		        ["staff2"] = {
            Trade = false,
            Drop = false,
            Sell = false,
            PersonalStore = false,
        },
		
				["staff3"] = {
            Trade = false,
            Drop = false,
            Sell = false,
            PersonalStore = false,
        },
		
        ["tela"] = {
            Trade = false,
            Drop = false,
            Sell = false,
            PersonalStore = false,
        },	

        ["david"] = {
            Trade = false,
            Drop = false,
            Sell = false,
            PersonalStore = false,
        },
		
    },

    Message = {
        ["Eng"] = {
            [1] = "Sua conta é para suporte!",
        },
        ["Por"] = {
            [1] = "Sua conta é para suporte!",
        },
        ["Spn"] = {
            [1] = "Sua conta é para suporte!",
        },
    }
}