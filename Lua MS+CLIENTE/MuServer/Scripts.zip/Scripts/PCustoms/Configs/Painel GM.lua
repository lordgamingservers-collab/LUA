PainelGM_Config = {
    Enabled = true,

    Command = {
        ["Eng"] = "/gmpanel",
        ["Por"] = "/painelgm",
        ["Spn"] = "/painelgm",
    },

    Packet = 21
}