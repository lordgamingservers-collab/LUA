-----------------------------------------
	-- Script:		NPC Horas
	-- Criador:		Pedro Borges
	-- Skype:		live:ppborges93
	-- WhatsApp:	+55 51 99507-8287
	-- Servidor:	King
-----------------------------------------

-- true ativa o sistema, false desativa
NPCHoras_Ativado = true

-- Numero do packet usado pelo sistema (tem que ser o mesmo no cliente)
NPCHoras_Packet = 121

-- true Conta como online quando esta em offattack, offhelper e offstore, false n?o conta
-- s? use false se estiver no update 65+, updates anteriores nao tem essa fun??o
NPCHoras_ContarOffline = false

-- Classe do Monstro
-- N�mero do Mapa
-- Coordenada X
-- Coordenada Y
-- Dire��o do Monstro
NPCHoras_Monstro = {

Classe = 415, Mapa = 0, X = 130, Y = 121, Dir = 3
}

NPCHoras_Tabela		= "CashShopData"
NPCHoras_ColunaHora	= "HorasOn"
NPCHoras_ColunaTemp	= "HorasTemp"
NPCHoras_Where		= "AccountID"
NPCHoras_Tipo		= 0


NPCHoras_Itens = {
 [1 ] = {Nome = "Box Fenrir's Classicos",	     	 Valor = 10, Grupo = 14,   Id = 57,   Level = 0, Dur = 0, Skill = 0, Luck = 0, Option = 0, Exc = 00},
 [2 ] = {Nome = "Box ALL Tail Fox",	     	 Valor = 10, Grupo = 14,   Id = 33,   Level = 0, Dur = 0, Skill = 0, Luck = 0, Option = 0, Exc = 00},

}
