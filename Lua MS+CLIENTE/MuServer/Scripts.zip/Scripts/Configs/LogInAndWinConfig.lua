LOG_IN_AND_WIN_SWITCH = 0

--Dias o jogador receber� recompensa, obs: o m�nimo � 5 dias!
--n�o tem limite m�ximo de dias, voc� pode colocar todos os n�meros
--client precisa permanecer igual!
LOG_IN_AND_WIN_MAX_DAYS = 0

-- true Ativa a limita��o por IP, 1 conta por IP
SL_LimitIp = false
--Min tempo em segundos para obter recompensa
LOG_IN_AND_WIN_GET_REWARD_MIN_TIME = 0 -- 120 = log and win

--packet number
LOG_IN_AND_WIN_PACKET = 2
--packet name
LOG_IN_AND_WIN_PACKET_NAME = 'GET_REWARD_LOG_IN'

LOG_IN_AND_WIN_REWARD_BY_DAYS = { }

--Day � a identifica��o da REWARD voc� precisa configurar LOG_IN_AND_WIN_REWARDS_PLAYER na base do Day!
LOG_IN_AND_WIN_REWARD_BY_DAYS[1] =    { Day = 1,   RewardName = '[1]Reward Lovers Box',        Quantity = 1,        RewardGet =      '[1]Reward Lovers Box'  }  


--isso fica apenas no servidor do jogo, n�o coloque no cliente, aqui recompensa o jogador!
--RewardType: 0 = Item, 1 = coisas que adicionam dados baseados em monumentos
--RewardIdentification: 0 = voc� precisa colocar o n�mero de LOG_IN_AND_WIN_REWARD_ITENS, 1 = voc� precisa colocar o n�mero de LOG_IN_AND_WIN_REWARD_COINS
LOG_IN_AND_WIN_REWARDS_PLAYER = {}

LOG_IN_AND_WIN_REWARDS_PLAYER[1] = {
{ RewardType = 0, RewardIdentification = 1},
}


-------------------------------
----- RECOMPENSA EM ITENS ----
-------------------------------
LOG_IN_AND_WIN_REWARD_ITENS = {}



LOG_IN_AND_WIN_REWARD_ITENS[1] = {
{ ItemIndex = GET_ITEM(14, 251), Level = 0, Op1 = 0, Op2 = 0, Life = 0, Exc = 0, Ancient = 0, JoH = 0, SocketBonus = 0, Sock1 = 0, Sock2 = 0, Sock3 = 0, Sock4 = 0, Sock5 = 0, DaysExpire = 45, Name = 'Lovers Box Reward', Count = 1},
}



-----------------------
----- Coins Config ----
-----------------------
LOG_IN_AND_WIN_REWARD_COINS = {}

LOG_IN_AND_WIN_REWARD_COINS[1] = {
{ Table = 'CashShopData', Column = 'WCoinC', Where = 'AccountID', Amounts = 10, Name = 'HPoints' },
}



--[[
Messages configs
]]--
LOG_IN_AND_WIN_MESSAGES = {}

LOG_IN_AND_WIN_MESSAGES['Por'] = {
[1] = 'Voc� foi premiado com: %d %s',
[2] = 'Voc� est� ocupado no momento!',
[3] = 'Ocorreu um erro na premia��o, contate a administra��o.',
[4] = 'Ocorreu um erro, contate a administra��o.',
}

LOG_IN_AND_WIN_MESSAGES['Eng'] = {
[1] = 'You have been awarded: %d %s',
[2] = 'You are currently busy!',
[3] = 'There was an error in the award, please contact the administration.',
[4] = 'An error has occurred, please contact the administration.',
}

LOG_IN_AND_WIN_MESSAGES['Spn'] = {
[1] = 'Se le otorg�: %d %s',
[2] = '�Actualmente est�s ocupado!',
[3] = 'Hubo un error en el premio, comun�quese con la administraci�n.',
[4] = 'Se produjo un error, comun�quese con la administraci�n.',
}

--[[
Configs SQL
]]--

LOG_IN_AND_WIN_TABLE_TIMEONLINE = 'MEMB_STAT'
LOG_IN_AND_WIN_COLUMN_TIMEONLINE = 'TimeOnlineLogIn'
LOG_IN_AND_WIN_WHERE_TIMEONLINE = 'memb___id'

LOG_IN_AND_WIN_TABLE_DAY = 'MEMB_STAT'
LOG_IN_AND_WIN_COLUMN_DAY = 'LogInDay'
LOG_IN_AND_WIN_WHERE_DAY = 'memb___id'

LOG_IN_AND_WIN_TABLE_CHECK = 'MEMB_STAT'
LOG_IN_AND_WIN_COLUMN_CHECK = 'LogInAndWinReward'
LOG_IN_AND_WIN_WHERE_CHECK = 'memb___id'
