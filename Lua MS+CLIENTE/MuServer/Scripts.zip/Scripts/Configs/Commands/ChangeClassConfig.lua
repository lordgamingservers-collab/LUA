--[[
Commands Config
]]--
-- Configura��es comando mudar classe
COMMAND_CHANGE_CLASS_SM = "/virarsm"
COMMAND_CHANGE_CLASS_BK = "/virarbk"
COMMAND_CHANGE_CLASS_ELF = "/virarelf"
COMMAND_CHANGE_CLASS_MG = "/virarmg"
--COMMAND_CHANGE_CLASS_DL = "/virardl"
--COMMAND_CHANGE_CLASS_SUM = "/virarrf"
--COMMAND_CHANGE_CLASS_RF = "/virarsum"
COMMAND_CHANGE_CLASS_SWITCH = 1
COMMAND_CHANGE_CLASS_LEVEL = 1
COMMAND_CHANGE_CLASS_RESETS = 0
COMMAND_CHANGE_CLASS_MRESETS = 0
COMMAND_CHANGE_CLASS_VIP = 0
COMMAND_CHANGE_CLASS_MONEY = 1000000

--[[
Messager Config
]]--
CHANGE_CLASS_MESSAGES = {  }

CHANGE_CLASS_MESSAGES["Por"] = {
[1] = "[Sistema] Feche outras janelas para realizar essa a��o.",
[2] = "[Sistema] Voc� precisa estar acima do level %d",
[3] = "[Sistema] Voc� precisa de %d zen",
[4] = "[Sistema] Somente usu�rios vip podem usar este comando!",
[5] = "[Sistema] Voc� precisa de %d resets",
[6] = "[Sistema] Voc� precisa de %d M.Resets",
[7] = "[Sistema] RETIRE SEUS ITENS!",
[8] = "Voc� precisa remover os itens equipados antes de utilizar o comando.",
[9] = "[Sistema] Voc� j� est� com a classe Soul Master",
[10] = "[Sistema] Voc� trocou de classe e se tornou um Soul Master!",
[11] = "[Sistema] Voc� j� est� com a classe Blade Knight",
[12] = "[Sistema] Voc� trocou de classe e se tornou um Blade Knight!",
[13] = "[Sistema] Voc� j� est� com a classe Muse Elf",
[14] = "[Sistema] Voc� trocou de classe e se tornou uma Muse Elf",
[15] = "[Sistema] Voc� j� est� com a classe Magic Gladiador",
[16] = "[Sistema] Voc� trocou de classe e se tornou uma Magic Gladiador",
[17] = "[Sistema] Voc� j� est� com a classe Dark Lord",
[18] = "[Sistema] Voc� trocou de classe e se tornou uma Dark Lord",
[19] = "[Sistema] Voc� j� est� com a classe Summoner",
[20] = "[Sistema] Voc� trocou de classe e se tornou uma Summoner",
[21] = "[Sistema] Voc� j� est� com a classe Rage Fight",
[22] = "[Sistema] Voc� trocou de classe e se tornou uma Rage Fight",
}

CHANGE_CLASS_MESSAGES["Eng"] = {
[1] = "[Sistema] Feche outras janelas para realizar essa a��o.",
[2] = "[Sistema] Voc� precisa estar acima do level %d",
[3] = "[Sistema] Voc� precisa de %d zen",
[4] = "[Sistema] Somente usu�rios vip podem usar este comando!",
[5] = "[Sistema] Voc� precisa de %d resets",
[6] = "[Sistema] Voc� precisa de %d M.Resets",
[7] = "[Sistema] RETIRE SEUS ITENS!",
[8] = "Voc� precisa remover os itens equipados antes de utilizar o comando.",
[9] = "[Sistema] Voc� j� est� com a classe Soul Master",
[10] = "[Sistema] Voc� trocou de classe e se tornou um Soul Master!",
[11] = "[Sistema] Voc� j� est� com a classe Blade Knight",
[12] = "[Sistema] Voc� trocou de classe e se tornou um Blade Knight!",
[13] = "[Sistema] Voc� j� est� com a classe Muse Elf",
[14] = "[Sistema] Voc� trocou de classe e se tornou uma Muse Elf",
[15] = "[Sistema] Voc� j� est� com a classe Magic Gladiador",
[16] = "[Sistema] Voc� trocou de classe e se tornou uma Magic Gladiador",
[17] = "[Sistema] Voc� j� est� com a classe Dark Lord",
[18] = "[Sistema] Voc� trocou de classe e se tornou uma Dark Lord",
[19] = "[Sistema] Voc� j� est� com a classe Summoner",
[20] = "[Sistema] Voc� trocou de classe e se tornou uma Summoner",
[21] = "[Sistema] Voc� j� est� com a classe Rage Fight",
[22] = "[Sistema] Voc� trocou de classe e se tornou uma Rage Fight",
}

CHANGE_CLASS_MESSAGES["Spn"] = {
[1] = "[Sistema] Feche outras janelas para realizar essa a��o.",
[2] = "[Sistema] Voc� precisa estar acima do level %d",
[3] = "[Sistema] Voc� precisa de %d zen",
[4] = "[Sistema] Somente usu�rios vip podem usar este comando!",
[5] = "[Sistema] Voc� precisa de %d resets",
[6] = "[Sistema] Voc� precisa de %d M.Resets",
[7] = "[Sistema] RETIRE SEUS ITENS!",
[8] = "Voc� precisa remover os itens equipados antes de utilizar o comando.",
[9] = "[Sistema] Voc� j� est� com a classe Soul Master",
[10] = "[Sistema] Voc� trocou de classe e se tornou um Soul Master!",
[11] = "[Sistema] Voc� j� est� com a classe Blade Knight",
[12] = "[Sistema] Voc� trocou de classe e se tornou um Blade Knight!",
[13] = "[Sistema] Voc� j� est� com a classe Muse Elf",
[14] = "[Sistema] Voc� trocou de classe e se tornou uma Muse Elf",
[15] = "[Sistema] Voc� j� est� com a classe Magic Gladiador",
[16] = "[Sistema] Voc� trocou de classe e se tornou uma Magic Gladiador",
[17] = "[Sistema] Voc� j� est� com a classe Dark Lord",
[18] = "[Sistema] Voc� trocou de classe e se tornou uma Dark Lord",
[19] = "[Sistema] Voc� j� est� com a classe Summoner",
[20] = "[Sistema] Voc� trocou de classe e se tornou uma Summoner",
[21] = "[Sistema] Voc� j� est� com a classe Rage Fight",
[22] = "[Sistema] Voc� trocou de classe e se tornou uma Rage Fight",
}