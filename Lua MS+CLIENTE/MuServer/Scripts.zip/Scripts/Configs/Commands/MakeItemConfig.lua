
MAKE_COMMAND_SWITCH = 1

--[[Uso /make
	Uso /make Section IndexItem NumberFull 
	Section - Seção do item
	IndexItem = Index do item
	NumberFull = 0 para não full e 1 para full
	QTdItem = 1 em diante
	Ex: /make 0 5 1 Cria a sword index 5 Full 
]]--
MAKE_COMMAND_ITEM = "/make"

--[[Uso /makeset
	IndexSet = Index de qualquer parte do set, tanto faz
	NumberFull = 0 para não full e 1 para full
	Ex: /makeset 5 1 Cria o set Leather full 
]]--
MAKE_COMMAND_SET = "/makeset" 

--[[Uso do /makeopt
	Esse comando é para criar itens com options separado, podendo colocar o que quiser de add.
	O comando segue essa sequencia de comandos.
	section: Seção do item
	index: Index do item
	level: Level +0 até +15
	luck: 0 pra não ter, 1 pra ter
	skill: 0 pra não ter, 1 pra ter
	opt: 
	exc: Adds ex no item
	qtd: Quantidade de itens
	/makeopt 0 1 15 1 1 7 62 10 --Vai criar 10 swodrs full +15
]]--
COMMAND_MAKEITEM_OPT = "/axopt"

MAKE_COMMAND_AUTORIZATION	= { 
	--[[Configure quem pode ou não utilizar o comando.
		_login = Inserir o Login que terá permissão
		_char = Insira aqui caso queira que na conta, somente 1 personagem utilize o comando.
		_somenteChar = True para habilitar que somente um personagem use o comando, personagem esse
		configurado no _char, false ele vai ignorar esse campo
	]]--

	{_login = "admin", _char = "admin", _somenteChar = false},


}