--[[
Commands Configs
]]--
TRACE_COMMAND = "/trace"
TRACE_SWITCH = 1
TRACE_GAME_MASTER_LEVEL = 1

--[[
Message Configs
]]--
TRACE_MESSAGES = { }

TRACE_MESSAGES["Por"] = {
[1] = "[Sistema] %s est� offline ou n�o existe",
}

TRACE_MESSAGES["Eng"] = {
[1] = "[Sistema] %s est� offline ou n�o existe",
}

TRACE_MESSAGES["Spn"] = {
[1] = "[Sistema] %s est� offline ou n�o existe",
}