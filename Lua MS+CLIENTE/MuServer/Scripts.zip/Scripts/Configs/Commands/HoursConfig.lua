--[[
Command Configs
]]--
HORAS_COMMAND = "/horas"
HORAS_SWITCH = 1
HORAS_LEVEL = 1
HORAS_RESETS = 0
HORAS_MRESETS = 0
HORAS_VIP = 0
HORAS_MONEY = 0

--[[
Message Configs
]]--

HOUR_MESSAGE = { }

HOUR_MESSAGE["Por"] = {
[1] = "[Sistema] Voc� precisa estar acima do level %d",
[2] = "[Sistema] Voc� precisa de %d zen",
[3] = "[Sistema] Somente usu�rios vip podem usar este comando!",
[4] = "[Sistema] Voc� precisa de %d resets",
[5] = "[Sistema] Voc� precisa de %d M.Resets",
[6] = "Hoje � %c",
}

HOUR_MESSAGE["Eng"] = {
[1] = "[Sistema] Voc� precisa estar acima do level %d",
[2] = "[Sistema] Voc� precisa de %d zen",
[3] = "[Sistema] Somente usu�rios vip podem usar este comando!",
[4] = "[Sistema] Voc� precisa de %d resets",
[5] = "[Sistema] Voc� precisa de %d M.Resets",
[6] = "Hoje � %c",
}

HOUR_MESSAGE["Spn"] = {
[1] = "[Sistema] Voc� precisa estar acima do level %d",
[2] = "[Sistema] Voc� precisa de %d zen",
[3] = "[Sistema] Somente usu�rios vip podem usar este comando!",
[4] = "[Sistema] Voc� precisa de %d resets",
[5] = "[Sistema] Voc� precisa de %d M.Resets",
[6] = "Hoje � %c",
}