-----------------------------------------
	-- Script:		Aluguel de Item
	-- Criador:		Pedro Borges
-----------------------------------------

RentItem_Config = {
	Enabled = false,

	Command = {
		["Eng"] = "/alugar",
		["Por"] = "/alugar",
		["Spn"] = "/alugar"
	},

	Coin = {
		[1] = {
			Name = "Golds",
			Table = "MEMB_INFO",
			Column = "gold",
			Where = "memb___id",
			IdType = 0 -- 0 Login, 1 Nick	
		},
		[2] = {
			Name = "WCoinP",
			Table = "CashShopData",
			Column = "WCoinP",
			Where = "AccountID",
			IdType = 0 -- 0 Login, 1 Nick	
		},
		[3] = {
			Name = "Golds",
			Table = "MEMB_INFO",
			Column = "gold",
			Where = "memb___id",
			IdType = 0 -- 0 Login, 1 Nick	
		},
	},

	Item = {
		--["identificador"] = {nomde do item, index da moeda, pre�o para alugar, ativa/desativa aluguel para o vip}
		-- identificador tem que ser minusculo. No jogo o player pode digitar de qualquer forma, apenas na configura��o que � obrigat�ria ser minusculo
		-- exemplo de uso: /alugar dragon knight set

		["all"] = 	{Name = "all", 	 Coin = 100, Price = 0, Vip = {[0] = true, [1] = true, [2] = true}},

	},

	Result = {


		["all"] = { -- TimerExpire em segundos, (86400*7) = 7 dias
			{Section = 7 , Index = 278, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 8 , Index = 278, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 9 , Index = 278, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 10, Index = 278, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 11, Index = 278, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 0, Index = 132, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 0, Index = 133, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 6, Index = 257, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 12, Index = 313, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 13, Index = 285, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 13, Index = 287, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 15, Index = 448, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 15, Index = 449, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 15, Index = 449, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 15, Index = 450, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 15, Index = 451, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},
			{Section = 15, Index = 452, Level = 15, Op1 = 1, Op2 = 1, Life = 7, Exc = 63, Ancient = 0, JoH = 0, SocketBonus = 255, Sock1 = 255, Sock2 = 255, Sock3 = 255, Sock4 = 255, Sock5 = 255, TimeExpire = (12340*1)},



		},

	},

	Message = {
		["Eng"] = {
			[1] = " Item n�o localizado ",
			[2] = " Voc� precisa de %d %s para alugar o item ",
			[3] = " Seu invet�rio precisa estar vazio ",
			[4] = " Esse item n�o est� dispon�vel para o seu plano vip ",
			[5] = " Voc� alugou 1 %s por %d %s"
		},
		
		["Por"] = {
			[1] = " Item n�o localizado ",
			[2] = " Voc� precisa de %d %s para alugar o item ",
			[3] = " Seu invet�rio precisa estar vazio ",
			[4] = " Esse item n�o est� dispon�vel para o seu plano vip ",
			[5] = " Voc� alugou 1 %s por %d %s"
		},
		
		["Spn"] = {
			[1] = " Item n�o localizado ",
			[2] = " Voc� precisa de %d %s para alugar o item ",
			[3] = " Seu invet�rio precisa estar vazio ",
			[4] = " Esse item n�o est� dispon�vel para o seu plano vip ",
			[5] = " Voc� alugou 1 %s por %d %s"
		},
	}

}

return RentItem_Config