--[[
Command Config
]]--
--this command is only staff
--/premiar <nick> <number config> <coins amount>
REWARD_PLAYERS_SWITCH = 1
REWARD_PLAYERS_COMMAND = '/premiar'
REWARD_PLAYERS_GAME_MASTER_LEVEL = 2
REWARD_ANNOUNCE_GLOBAL = 1

REWARD_PLAYERS_CONFIGS = { }


REWARD_PLAYERS_CONFIGS[1] = {
Table = 'CashShopData',
Column = 'WCoinC',
Where = 'AccountID',
CoinName = 'Cash',
MaxReward = -1 , --  max coin amount reward -1 = no limit
}

REWARD_PLAYERS_CONFIGS[2] = {
Table = 'CashShopData',
Column = 'WCoinP',
Where = 'AccountID',
CoinName = 'Gold',
MaxReward = -1, --  max coin amount reward -1 = no limit
}
REWARD_PLAYERS_CONFIGS[3] = {
Table = 'CashShopData',
Column = 'HorasOn',
Where = 'AccountID',
CoinName = 'Horas',
MaxReward = -1, --  max coin amount reward -1 = no limit
}

--[[
Command Message
]]--
--Global users message
REWARD_PLAYERS_GLOBAL_MESSAGES = { }

REWARD_PLAYERS_GLOBAL_MESSAGES['Por'] = {
[1] = '[%s] Premiou',
[2] = '%d %s para %s',
}

REWARD_PLAYERS_GLOBAL_MESSAGES['Eng'] = {
[1] = '[%s] Premiou',
[2] = '%d %s para %s',
}

REWARD_PLAYERS_GLOBAL_MESSAGES['Spn'] = {
[1] = '[%s] Premiou',
[2] = '%d %s para %s',
}

--Staff message
REWARD_PLAYERS_MESSAGES = {}

REWARD_PLAYERS_MESSAGES['Por'] = {
[1] = 'Uso incorreto do comando: <nick> <valor do premio> <quantidade>',
[2] = 'O numero dessa premia��o n�o foi encontrado!',
[3] = 'Ocorreu algum problema ao identificar a premia��o',
[4] = 'O limite de moedas a ser adiciona � %d',
[5] = 'O jogador %s n�o est� online ou n�o existe',
[6] = 'Sua premia��o %d %s, foi adicionada',
}

REWARD_PLAYERS_MESSAGES['Eng'] = {
[1] = 'Uso incorreto do comando: <nick> <valor do premio> <quantidade>',
[2] = 'O numero dessa premia��o n�o foi encontrado!',
[3] = 'Ocorreu algum problema ao identificar a premia��o',
[4] = 'O limite de moedas a ser adiciona � %d',
[5] = 'O jogador %s n�o est� online ou n�o existe',
[6] = 'Sua premia��o %d %s, foi adicionada',
}

REWARD_PLAYERS_MESSAGES['Spn'] = {
[1] = 'Uso incorreto do comando: <nick> <valor do premio> <quantidade>',
[2] = 'O numero dessa premia��o n�o foi encontrado!',
[3] = 'Ocorreu algum problema ao identificar a premia��o',
[4] = 'O limite de moedas a ser adiciona � %d',
[5] = 'O jogador %s n�o est� online ou n�o existe',
[6] = 'Sua premia��o %d %s, foi adicionada',
}