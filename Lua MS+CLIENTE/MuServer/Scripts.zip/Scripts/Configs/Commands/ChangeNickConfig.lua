--[[
Command Configs
]]--
CHANGE_NICK_COMMAND = '/nome'
CHANGE_NICK_SWITCH = 1 
CHANGE_NICK_LEVEL = 1
CHANGE_NICK_ZEN = 0
CHANGE_NICK_VIP = 1
CHANGE_NICK_RESETS = 0
CHANGE_NICK_MRESETS = 0
CHANGE_NICK_MIN_LEN = 2 -- comprimento m�nimo de caracteres para o novo nome
CHANGE_NICK_CHECK_SYMBOL = 0 -- verifique o s�mbolo no nick


--[[
Command Message
]]--
CHANGE_NICK_MESSAGE = {}

CHANGE_NICK_MESSAGE["Por"] = {
[1] = "Voc� precisa estar acima do level %d para usar o comando",
[2] = "Voc� precisa ter %d zen para usar o comando",
[3] = "Comando para jogadores VIP",
[4] = "Voc� precisa de %d resets para usar o comando",
[5] = "Voc� precisa de %d mresets para usar o comando",
[6] = "Voc� precisa colocar um NICK v�lido",
[7] = "O m�nimo de caracteres para alterar nick � %d",
[8] = "Voc� est� utilizando caracteres impr�prios!",
[9] = "Infelizmente o nick que voc� est� tentando trocar j� existe!",
[10] = "Seu nick foi alterado com sucesso, relogando personagem",
[11] = "Ocorreu um problema ao efetuar a Troca de nome!",
[12] = "Voc� precisa sair da guild antes de tentar trocar o nome!",
}

CHANGE_NICK_MESSAGE["Eng"] = {
[1] = "Voc� precisa estar acima do level %d para usar o comando",
[2] = "Voc� precisa ter %d zen para usar o comando",
[3] = "Comando para jogadores VIP",
[4] = "Voc� precisa de %d resets para usar o comando",
[5] = "Voc� precisa de %d mresets para usar o comando",
[6] = "Voc� precisa colocar um NICK v�lido",
[7] = "O m�nimo de caracteres para alterar nick � %d",
[8] = "Voc� est� utilizando caracteres impr�prios!",
[9] = "Infelizmente o nick que voc� est� tentando trocar j� existe!",
[10] = "Seu nick foi alterado com sucesso, relogando personagem",
[11] = "Ocorreu um problema ao efetuar a Troca de nome!",
[12] = "Voc� precisa sair da guild antes de tentar trocar o nome!",
}

CHANGE_NICK_MESSAGE["Spn"] = {
[1] = "Voc� precisa estar acima do level %d para usar o comando",
[2] = "Voc� precisa ter %d zen para usar o comando",
[3] = "Comando para jogadores VIP",
[4] = "Voc� precisa de %d resets para usar o comando",
[5] = "Voc� precisa de %d mresets para usar o comando",
[6] = "Voc� precisa colocar um NICK v�lido",
[7] = "O m�nimo de caracteres para alterar nick � %d",
[8] = "Voc� est� utilizando caracteres impr�prios!",
[9] = "Infelizmente o nick que voc� est� tentando trocar j� existe!",
[10] = "Seu nick foi alterado com sucesso, relogando personagem",
[11] = "Ocorreu um problema ao efetuar a Troca de nome!",
[12] = "Voc� precisa sair da guild antes de tentar trocar o nome!",
}