--[[
Commands Configs
]]--
POST_COMMAND = "/post"
POST_STRING = "[Post] %s:%s"
POST_SWITCH = 1
POST_LEVEL = 100
POST_MONEY = 2000000
POST_RESET = 40
POST_MRESET = 0
POST_VIP = 0
POST_COLOR = 3
POST_TIMER = 0

--[[
Message Configs
]]--
POST_MESSAGES = { }

POST_MESSAGES["Por"] = {
[1] = "[Sistema] Voc� tem que esperar %d segundo(s) para utilizar o %s novamente.",
[2] = "[Sistema] Voc� precisa estar acima do level %d",
[3] = "[Sistema] Voc� precisa de %d zen",
[4] = "[Sistema] Somente usu�rios vip podem usar este comando!",
[5] = "[Sistema] Voc� precisa de %d resets",
[6] = "[Sistema] Voc� precisa de %d M.Resets",
}

POST_MESSAGES["Eng"] = {
[1] = "[Sistema] Voc� tem que esperar %d segundo(s) para utilizar o %s novamente.",
[2] = "[Sistema] Voc� precisa estar acima do level %d",
[3] = "[Sistema] Voc� precisa de %d zen",
[4] = "[Sistema] Somente usu�rios vip podem usar este comando!",
[5] = "[Sistema] Voc� precisa de %d resets",
[6] = "[Sistema] Voc� precisa de %d M.Resets",
}

POST_MESSAGES["Spn"] = {
[1] = "[Sistema] Voc� tem que esperar %d segundo(s) para utilizar o %s novamente.",
[2] = "[Sistema] Voc� precisa estar acima do level %d",
[3] = "[Sistema] Voc� precisa de %d zen",
[4] = "[Sistema] Somente usu�rios vip podem usar este comando!",
[5] = "[Sistema] Voc� precisa de %d resets",
[6] = "[Sistema] Voc� precisa de %d M.Resets",
}