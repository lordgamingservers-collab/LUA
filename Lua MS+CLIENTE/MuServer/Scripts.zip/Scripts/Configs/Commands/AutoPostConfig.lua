--[[
Command Configs
--]]
-- Configura��es comando /autopost
AUTO_POST_COMMAND = "/autopost"
AUTO_POST_STRING = "[AutoPost] %s:%s"
AUTO_POST_SWITCH = 1
AUTO_POST_LEVEL = 500
AUTO_POST_MONEY = 2000000
AUTO_POST_RESET = 0
AUTO_POST_MRESET = 0
AUTO_POST_VIP = 0
AUTO_POST_COLOR = 30
AUTO_POST_TIMER = 150

--[[
Messager Configs
]]--
AUTO_POST_MESSAGES = {  }

AUTO_POST_MESSAGES["Por"] = {
[1] = "[Sistema] Auto post desativado.",
[2] = "[Sistema] Voc� j� est� utilizando o comando %s",
[3] = "[Sistema] Voc� precisa estar acima do level %d para utilizar o auto post",
[4] = "[Sistema] Voc� precisa de %d zen para utilizar o auto post",
[5] = "[Sistema] Somente usu�rios vip podem usar este comando!",
[6] = "[Sistema] Voc� precisa de %d resets para utilizar o auto post",
[7] = "[Sistema] Voc� precisa de %d M.Resets para utilizar o auto post",
}

AUTO_POST_MESSAGES["Eng"] = {
[1] = "[Sistema] Auto post desativado.",
[2] = "[Sistema] Voc� j� est� utilizando o comando %s",
[3] = "[Sistema] Voc� precisa estar acima do level %d para utilizar o auto post",
[4] = "[Sistema] Voc� precisa de %d zen para utilizar o auto post",
[5] = "[Sistema] Somente usu�rios vip podem usar este comando!",
[6] = "[Sistema] Voc� precisa de %d resets para utilizar o auto post",
[7] = "[Sistema] Voc� precisa de %d M.Resets para utilizar o auto post",
}

AUTO_POST_MESSAGES["Spn"] = {
[1] = "[Sistema] Auto post desativado.",
[2] = "[Sistema] Voc� j� est� utilizando o comando %s",
[3] = "[Sistema] Voc� precisa estar acima do level %d para utilizar o auto post",
[4] = "[Sistema] Voc� precisa de %d zen para utilizar o auto post",
[5] = "[Sistema] Somente usu�rios vip podem usar este comando!",
[6] = "[Sistema] Voc� precisa de %d resets para utilizar o auto post",
[7] = "[Sistema] Voc� precisa de %d M.Resets para utilizar o auto post",
}