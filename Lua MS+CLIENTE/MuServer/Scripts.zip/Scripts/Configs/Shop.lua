Shop_Config = {
    Enabled = true,

    Packet = 9,

    Coins = {
        [1] = {Name = "HCash", Table = "MEMB_INFO", Column = "HCash", Where = "memb___id", IdType = 0},
        [2] = {Name = "HGold", Table = "MEMB_INFO", Column = "HGold", Where = "memb___id", IdType = 0},
        [3] = {Name = "EventPoint", Table = "MEMB_INFO", Column = "EventPoint", Where = "memb___id", IdType = 0},
    },

    Message = {
        ["Eng"] = {
            [1] = "Item Shop Purchase",
        },
        ["Por"] = {
            [1] = "Compra na Loja de Itens",
        },
        ["Spn"] = {
            [1] = "Compra na Loja de Itens",
        },
    }
}

return Shop_Config