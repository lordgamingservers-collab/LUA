--[[
Game Master Level
]]

GAME_MASTER_LEVEL = {}

GAME_MASTER_LEVEL['lordgaming'] =  { characterName = 'LordG', level = 2 }
GAME_MASTER_LEVEL['staff'] =  { characterName = 'STAFF',  level = 1 }
GAME_MASTER_LEVEL['staff1'] = { characterName = 'STAFFF', level = 1 }


function CheckGameMasterLevel(account, name, level)
    local gamemaster = GAME_MASTER_LEVEL[account]

    if gamemaster ~= nil
    then
        if name == gamemaster.characterName
        then
            if gamemaster.level >= level
            then
                return 1
            end
        end
    end

    return 0
end