
--[[
Command Messages
]]--

LIMPAR_INVENTARIO_MESSAGES = { }

LIMPAR_INVENTARIO_MESSAGES["Por"] = {
[1] = "[Sistema] O Invent�rio j� est� limpo!",
[2] = "[Sistema] Invent�rio limpo com sucesso!",
[3] = "[Sistema] Voc� est� ocupado no momento!",
}

LIMPAR_INVENTARIO_MESSAGES["Eng"] = {
[1] = "[Sistema] O Invent�rio j� est� limpo!",
[2] = "[Sistema] Invent�rio limpo com sucesso!",
[3] = "[Sistema] Voc� est� ocupado no momento!",
}

LIMPAR_INVENTARIO_MESSAGES["Spn"] = {
[1] = "[Sistema] O Invent�rio j� est� limpo!",
[2] = "[Sistema] Invent�rio limpo com sucesso!",
[3] = "[Sistema] Voc� est� ocupado no momento!",
}