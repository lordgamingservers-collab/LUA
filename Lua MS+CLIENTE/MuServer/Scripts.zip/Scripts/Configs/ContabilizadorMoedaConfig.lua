-- true ativa o sistema, false desativa
ContabilizadorCoin_Ativado = true

-- true Conta como online quando esta em offattack, offhelper e offstore, false n?o conta
ContabilizadorCoin_ContarOffline = true
ContabilizadorCoin_Tipo = 0

ContabilizadorCoin_Tabela		= "CashShopData"
ContabilizadorCoin_ColunaTemp	= "HorasOn"
ContabilizadorCoin_Where		= "AccountID"

ContabilizadorCoinConfig = {}
ContabilizadorCoinConfig[1] = {tabela = "CashShopData", column = "HorasOn", where = "AccountID", amountHour = 1}
--ContabilizadorCoinConfig[2] = {tabela = "CashShopData", column = "gold", where = "AccountID", amountHour = 1}
ContabilizadorCoinConfig[3] = {tabela = "BattlePass", column = "xpPass", where = "AccountID", amountHour = 100}