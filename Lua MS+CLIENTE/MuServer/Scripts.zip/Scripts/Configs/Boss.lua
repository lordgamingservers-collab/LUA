Boss_Config = {
    Enabled = true,

    Commands = {
        Start = { -- command to start an invasion manually,  /command <index>  Ex: /startboss 1
            ["Eng"] = "/invocar",
            ["Por"] = "/invocar",
            ["Spn"] = "/invocar"
        },

        End = { -- command to end an invasion manually,  /command <index>  Ex: /endboss 1
            ["Eng"] = "/invocarf",
            ["Por"] = "/invocarf",
            ["Spn"] = "/invocarf"
        }
    },

    Cron = {-- Boss = invasion inde
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 10, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 11, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 12, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 13, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 14, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 15, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 16, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 17, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 18, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 19, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 20, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 21, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 22, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 23, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 00, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 01, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 02, Minute = 00},
      {Boss = 1, Day = -1, WeekDay = -1, Hour = 03, Minute = 00},
	  

 
    }, 

    Boss = {
        [1] = {-- [invasion index]
            Name = "Erohim - Invasion", -- Just to identify in logs, not shown to player
            EventTime = 5, -- time in minutes
            AnnounceDeath = true, -- announce that a player killed a monster
            AnnounceMonsters = true, -- announce how many monsters are still alive
            Message = {
                ["Eng"] ={
                    [1] = "Erohim Invasion Come�ou",
                    [2] = "Erohim Invasion terminou!",
                    [3] = "[Erohim Invasion]",
                },
                ["Por"] ={
                    [1] = "Erohim Invasion Come�ou",
                    [2] = "Erohim Invasion terminou!",
                    [3] = "[Erohim Invasion]",
                },
                ["Spn"] ={
                    [1] = "Erohim Invasion Come�ou",
                    [2] = "Erohim Invasion terminou!",
                    [3] = "[Erohim Invasion]",
                }
            }
        },

    },
    
    Monsters = {
		--[[
			Name = name of the monster
			Class = class of monster in monster.txt
			Map = Map where the monster will appear randomly
			Coun = amount of monsters
			Drop = drop index (0 to not give item)
			Coin = coin index (0 to not give coin)
			DropAll = true (drop all itens, false drop 1 item)
			CoinAll = true give all coins, false give 1 coin)
			RewardCoinAndDrop = true give item and coin (Drop and Coin must be > 0), false give item or coin
			DropToCoinRate = chacne of giving item over coin if RewardCoinAndDrop = false and Drop > 0 and Coin > 0
			[0] = rate for free,
			[1] = rate for vip 1,
			[2] = rate for vip 2, etc.
			]]
        [1] = {
            {Name = "Erohim Invasion", Class = 295, Map = 84, Count = 1, Drop = 0, Coin = 1, DropAll = false, CoinAll = false, RewardCoinAndDrop = true, DropToCoinRate = {[0] = 100, [1] = 100, [2] = 100, [3] = 100, [4] = 100}},
        },

    },

    Drops = {
		--[[
			[drop index] = {
			Section = group of item in item.txt
			Index = Id of item in item.txt
			LevelMin = Minimum level the item will have (0 to 15)
			LevelMax = Maximum level the item will have, Use same as LevelMin for fixed level (0 to 15)
			DurMin = Minimum durability the item will have (0 to 255) (in case of stack itens such as jewel, the durability is the amount if jewels in the stack)
			DurMax = Maximum durability the item will have, Use same as DurMin for fixed durability
			Skill and Luck = -1 random, 1 have, 0 doesn't have
			OptMin = Minimum JoL option the item will have (0 to 7)
			OptMax = Maximum JoL option the item will have, Use same as OptMin for fixed JoL option (0 to 7)
			ExcMin = Minumum excelent otpions the item will have (1 to 6) use 7 to try make wing with recovery HP option
			Excmax = Maximum excelent options the item will have, use same as ExcMin to fixed otions, use 7 to try make wing with recovery HP option
			DaysExpire = amount of days the item will last, 0 to normal item, >= 1 to periodic item
			Count = amount of itens
			DropInventory = true insert item in inventory if it has space, false drop on the ground
			DropRate = chance of droping this itens if DropAll = false
			[0] = rate for free,
			[1] = rate for vip 1, etc
			All the rates for a vip level should preferably sum to 100 as in the exemple below, there is 4 itens, and each has 25% chance of droping
			}
		]]
        [1] = {
            {Section = 14, Index = 22, LevelMin = 0, LevelMax = 0, DurMin = 0, DurMax = 0, Skill = 0, Luck = 0, OptMin = 0, OptMax = 0, ExcMin = 0, ExcMax = 0, DaysExpire = 0, Count = 1, DropInventory = true, DropRate = {[0] = 100, [1] = 100, [2] = 100, [3] = 100, [4] = 100}},
	    },	
    },

    Coins = {
	--[[
		[coin index] = {
			Name = name of coin
			Amount = how much coin to give
			Table = table on database
			Column = column in database
			Where = column on the database that identify the player that will get the coin
			IdType = 0 for login, 1 for nickname
			DropRate = chance of droping this itens if DropAll = false
			[0] = rate for free,
			[1] = rate for vip 1, etc
			All the rates for a vip level should preferably sum to 100 as in the exemple below, there is 2coins itens, and each has 50% chance of droping
		}
	]]
        [1] = {
            {Name = "Erohim Points", Amount = 1, Table = "Character", Column = "RankedUr", Where = "Name", IdType = 0, DropRate = {[0] = 100, [1] = 100, [2] = 100, [3] = 100, [4] = 100}},
        },
    },

    Message = {
        ["Eng"] = {
            [1] = "%s killed 1 %s",
            [2] = "%d monsters left alive!",
            [3] = " You received %d %s for killing 1 %s ",
            [4] = " Boss n�o encontrado, use %s <index> ",
            [5] = " Boss j� esta ativo, use %s <index>",
            [6] = " Boss n�o esta ativo, use %s <index>",
        },
        ["Por"] = {
            [1] = "%s matou 1 %s",
            [2] = "Restam %d monstros vivos!",
            [3] = " Voc� recebeu %d %s por matar 1 %s ",
            [4] = " Boss n�o encontrado, use %s <index> ",
            [5] = " Boss j� esta ativo, use %s <index>",
            [6] = " Boss n�o esta ativo, use %s <index>",
        },
        ["Spn"] = {
            [1] = "%s mat� 1 %s",
            [2] = "�%d monstruos quedan vivos!",
            [3] = " Voc� recebeu %d %s por matar 1 %s ",
            [4] = " Boss n�o encontrado, use %s <index> ",
            [5] = " Boss j� esta ativo, use %s <index>",
            [6] = " Boss n�o esta ativo, use %s <index>",
        },
    }
}

return Boss_Config