-----------------------------------------
	-- Script:  Conversor de Itens
	-- Criador: Pedro Borges
	-- Skype: live:ppborges93
-----------------------------------------

--Configura��es ConverterItem
CONVERT_ITEM_COMMAND	= "/trocar"	-- Sintaxe: /comando <nome> <quantidade> (Ex: /trocaritem style 2)
CONVERT_ITEM_TABLE		= "MEMB_INFO"	-- Tabela da moeda
CONVERT_ITEM_WHERE		= "memb___id"	-- Identificador da conta do player

-- Nome usado para identificar o item no comando
-- Section do item no item.txt
-- Index do item no item.txt
-- Level do item (-1 qualquer level)
-- Coluna da moeda
-- Nome da moeda
-- Valor que sera dado ao player por cada unidade do item.
CONVERT_ITEM_LIST = {
-- SWORD 

{Nome = "1 Milh�o de HPoints)",      Command = "hp", Section = 13, Index = 52,  Column = "hpoints", CoinName = "HPoints", Value = {[0] = 1000000, [1] = 1000000, [2] = 1000000, [3] = 1000000 , [4] = 1000000, [5] = 1000000, [6] = 1000000, [7] = 1000000, [8] = 1000000, [9] = 1000000, [10] = 1000000, [11] = 1000000, [12] = 1000000, [13] = 1000000, [14] = 1000000, [15] = 1000000}},

}