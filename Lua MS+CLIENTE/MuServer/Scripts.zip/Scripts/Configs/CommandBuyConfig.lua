--[[
Commands Config
]]--
BUY_COMMAND_SWITCH = 1 -- 1 Ative 0 Desative
BUY_COMMAND = "/comprar"

BUY_COMMAND_AMOUNT_TABLE = {}
BUY_COMMAND_AMOUNT_TABLE[0] = "CashShopData"

BUY_COMMAND_AMOUNT_COLUMN = {}
BUY_COMMAND_AMOUNT_COLUMN[0] = "WCoinC"

BUY_COMMAND_AMOUNT_WHERE = {}
BUY_COMMAND_AMOUNT_WHERE[0] = "AccountID"


-- IdType 0 = moeda (cash, jcpoint, etc..), IdType 1 = Resets, MResets, etc..
BUY_COMMAND_AMOUNT_TYPE = {}
BUY_COMMAND_AMOUNT_TYPE[0] = 0


BUY_COMMAND_AMOUNT_NAME = {}
BUY_COMMAND_AMOUNT_NAME[0] = "Cash"


--Name: Nome do item quando falar na mensagem
--String: Oque o cara vai usar para comprar exemplo /buy Bless, n�o � permitido utilizar espa�o exemplo "/buy bless bless", apenas "/buy packbles" "/buy bless" etc...
--AmountType: Tipo da moeda configurado acima 0 = primeira 1 = segunda etc...
--Amount: Quantidade que ser� cobrado
--Identification: Numero do item na BUY_COMMAND_ITENS
--ItemCount: Quantos itens ser�o editados
BUY_COMMAND_CONFIG = {

{Name = "Box Horus", 				String = "box",	 	AmountType = 0, Amount =  40000,  	 Identification = 0, ItemCount = 10},
{Name = "Set Bronze Completo", 				String = "setbronze",	 	AmountType = 0, Amount =  500,  	 Identification = 1, ItemCount = 1},
{Name = "Set Dragon Completo", 				String = "setdragon",	 	AmountType = 0, Amount =  500,  	 Identification = 2, ItemCount = 1},
{Name = "Set Leather Completo", 			String = "setleather",	 	AmountType = 0, Amount =  500,  	 Identification = 3, ItemCount = 1},
{Name = "Set Scale Completo", 				String = "setscale",	 	AmountType = 0, Amount =  500,  	 Identification = 4, ItemCount = 1},
{Name = "Set Brass Completo", 				String = "setbrass",	 	AmountType = 0, Amount =  500,  	 Identification = 5, ItemCount = 1},
{Name = "Set Plate Completo", 				String = "setplate",	 	AmountType = 0, Amount =  500,  	 Identification = 6, ItemCount = 1},
{Name = "Set Black Dragon Completo", 		String = "setblackdragon",	AmountType = 0, Amount =  500,  	 Identification = 7, ItemCount = 1},
{Name = "Set Dark Phoenix Completo", 		String = "setdp",			AmountType = 0, Amount =  500,  	 Identification = 8, ItemCount = 1},
{Name = "Wing Level 2 BK", 					String = "asa2bk",			AmountType = 0, Amount =  600,  	 Identification = 9, ItemCount = 1},
{Name = "Wing Level 2 SM", 					String = "asa2sm",			AmountType = 0, Amount =  600,  	 Identification = 10, ItemCount = 1},
{Name = "Wing Level 2 MG", 					String = "asa2mg",			AmountType = 0, Amount =  600,  	 Identification = 11, ItemCount = 1},
{Name = "Wing Level 2 ELF", 				String = "asa2elf",			AmountType = 0, Amount =  600,  	 Identification = 12, ItemCount = 1},

}

--Section: Se��o do item
--ItemIndex: Index do item
--IsSet: Se for 1 Set coloque a Section = 7 que o sistema automaticamente vai rolar do 7 ao 11 colocando 1 set no invent�rio
--As demais configura��es j� dizem por s�...
BUY_COMMAND_ITENS = {
--SET EXEMPLO {Identification = 1, Section = 7, Index = 24, IsSet = 1, Level = 15, Luck = 1, Skill = 1, Opt = 7, Exc_1 = 1, Exc_2 = 1, Exc_3 = 1, Exc_4 = 1, Exc_5 = 1, Exc_6 = 1},

{Identification = 0, Section = 14,  Index = 246  , IsSet = 0, Level = 0, Luck = 0, Skill = 0, Opt = 0, Exc_1 = 0, Exc_2 = 0, Exc_3 = 0, Exc_4 = 0, Exc_5 = 0, Exc_6 = 0},
{Identification = 1, Section = 7, Index = 0, IsSet = 1, Level = 15, Luck = 1, Skill = 1, Opt = 7, Exc_1 = 1, Exc_2 = 1, Exc_3 = 1, Exc_4 = 1, Exc_5 = 1, Exc_6 = 1},
{Identification = 2, Section = 7, Index = 1, IsSet = 1, Level = 15, Luck = 1, Skill = 1, Opt = 7, Exc_1 = 1, Exc_2 = 1, Exc_3 = 1, Exc_4 = 1, Exc_5 = 1, Exc_6 = 1},
{Identification = 3, Section = 7, Index = 5, IsSet = 1, Level = 15, Luck = 1, Skill = 1, Opt = 7, Exc_1 = 1, Exc_2 = 1, Exc_3 = 1, Exc_4 = 1, Exc_5 = 1, Exc_6 = 1},
{Identification = 4, Section = 7, Index = 6, IsSet = 1, Level = 15, Luck = 1, Skill = 1, Opt = 7, Exc_1 = 1, Exc_2 = 1, Exc_3 = 1, Exc_4 = 1, Exc_5 = 1, Exc_6 = 1},
{Identification = 5, Section = 7, Index = 8, IsSet = 1, Level = 15, Luck = 1, Skill = 1, Opt = 7, Exc_1 = 1, Exc_2 = 1, Exc_3 = 1, Exc_4 = 1, Exc_5 = 1, Exc_6 = 1},
{Identification = 6, Section = 7, Index = 9, IsSet = 1, Level = 15, Luck = 1, Skill = 1, Opt = 7, Exc_1 = 1, Exc_2 = 1, Exc_3 = 1, Exc_4 = 1, Exc_5 = 1, Exc_6 = 1},
{Identification = 7, Section = 7, Index = 16, IsSet = 1, Level = 15, Luck = 1, Skill = 1, Opt = 7, Exc_1 = 1, Exc_2 = 1, Exc_3 = 1, Exc_4 = 1, Exc_5 = 1, Exc_6 = 1},
{Identification = 8, Section = 7, Index = 17, IsSet = 1, Level = 15, Luck = 1, Skill = 1, Opt = 7, Exc_1 = 1, Exc_2 = 1, Exc_3 = 1, Exc_4 = 1, Exc_5 = 1, Exc_6 = 1},
{Identification = 9, Section = 12, Index = 370, IsSet = 0, Level = 15, Luck = 1, Skill = 1, Opt = 7, Exc_1 = 1, Exc_2 = 1, Exc_3 = 1, Exc_4 = 1, Exc_5 = 1, Exc_6 = 1},
{Identification = 10, Section = 12, Index = 372, IsSet = 0, Level = 15, Luck = 1, Skill = 1, Opt = 7, Exc_1 = 1, Exc_2 = 1, Exc_3 = 1, Exc_4 = 1, Exc_5 = 1, Exc_6 = 1},
{Identification = 11, Section = 12, Index = 373, IsSet = 0, Level = 15, Luck = 1, Skill = 1, Opt = 7, Exc_1 = 1, Exc_2 = 1, Exc_3 = 1, Exc_4 = 1, Exc_5 = 1, Exc_6 = 1},
{Identification = 12, Section = 12, Index = 371, IsSet = 0, Level = 15, Luck = 1, Skill = 1, Opt = 7, Exc_1 = 1, Exc_2 = 1, Exc_3 = 1, Exc_4 = 1, Exc_5 = 1, Exc_6 = 1},

}






--[[
Messager Config
]]--
COMMAND_BUY_MESSAGES = { }

COMMAND_BUY_MESSAGES["Por"] = {
[1] = "[Sistema] Para utilizar esse comando deixe seu invent�rio vazio!",
[2] = "Voc� precisa de %d %s para comprar este item!",
[3] = "[%s] adicionado em seu invent�rio!",
[4] = "N�o conseguimos encontrar o item!",
}

COMMAND_BUY_MESSAGES["Eng"] = {
[1] = "[Sistema] Para utilizar esse comando deixe seu invent�rio vazio!",
[2] = "Voc� precisa de %d %s para comprar este item!",
[3] = "[%s] adicionado em seu invent�rio!",
[4] = "N�o conseguimos encontrar o item!",
}

COMMAND_BUY_MESSAGES["Spn"] = {
[1] = "[Sistema] Para usar este comando, �deje su inventario vac�o!",
[2] = "�Necesitas %d %s para comprar este art�culo!",
[3] = "�[ %s] agregado a su inventario!",
[4] = "�No pudimos encontrar el art�culo!",
}