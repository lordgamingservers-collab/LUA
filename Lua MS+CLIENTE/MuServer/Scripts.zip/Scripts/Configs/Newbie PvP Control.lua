PvpControl_Config = {
    -- true Ativa o sistema, false desativa
    Ativado = false,

    -- Quantidade de resets que permite ativar o pvp
    Resets = 50000,

    -- Mapas onde o sistema funciona
    Mapas = {82,83,10},

    -- Mensagens do sistema
    Message = {
        ["Por"] = {
            [1] = "Mapa para Invas�o! PVP Off",
            [2] = "Vai em eventos PVP seu NOOB.",
            [3] = "Ent�o participe dos Eventos PVP!",
        },
        ["Eng"] = {
            [1] = "Mapa para Invas�o! PVP Off",
            [2] = "Vai em eventos PVP seu NOOB.",
            [3] = "Ent�o participe dos Eventos PVP!",
        },
        ["Spn"] = {
            [1] = "Mapa para Invas�o! PVP Off",
            [2] = "Vai em eventos PVP seu NOOB.",
            [3] = "Ent�o participe dos Eventos PVP!",
        },
    }
}

return PvpControl_Config