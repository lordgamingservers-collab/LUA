Ranking_Config = {
    Enabled = true,

    Packet = 9,

    Categories = {
        [1] =  {Table = "Character",     PointsColumn = "Resets"   ,          PlayerColumn = "Name", Time = {Show = false, Column = ""}},
        [2] =  {Table = "Character",     PointsColumn = "MResets"  ,          PlayerColumn = "Name", Time = {Show = false, Column = ""}},
	
    }

}

return Ranking_Config