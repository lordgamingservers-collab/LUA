FragmentStore_Config = {

    Enabled = true,

    Packet = 63,

    Npc = {Class = 416, Map = 0, PosX = 139, PosY = 143},

    --FragmentItem = GET_ITEM(14, 226),

    FragmentItem = { ItemIndex = GET_ITEM(14, 226), X = 25, Y = 25,  Size = "1.0"},

    Itens = {
        {Price = 5000, ItemIndex = GET_ITEM(07, 284), Level = 15, Dur = 255, Skill = 0, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 0, Name = "Ruined Style Helm (M) [RL]",   X = 20, Y = 27, Size = "1.2"},
        {Price = 5000, ItemIndex = GET_ITEM(08, 284), Level = 15, Dur = 255, Skill = 0, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 0, Name = "Ruined Style Armor (M) [RL]",  X = 20, Y = 32, Size = "1.2"},
        {Price = 5000, ItemIndex = GET_ITEM(09, 284), Level = 15, Dur = 255, Skill = 0, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 0, Name = "Ruined Style Pants (M) [RL]",  X = 20, Y = 32, Size = "1.2"},
        {Price = 5000, ItemIndex = GET_ITEM(10, 284), Level = 15, Dur = 255, Skill = 0, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 0, Name = "Ruined Style Gloves (M) [RL]", X = 20, Y = 32, Size = "1.2"},
        {Price = 5000, ItemIndex = GET_ITEM(11, 284), Level = 15, Dur = 255, Skill = 0, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 0, Name = "Ruined Style Boots (M) [RL]",  X = 20, Y = 32, Size = "1.2"},

        {Price = 5000, ItemIndex = GET_ITEM(07, 285), Level = 15, Dur = 255, Skill = 0, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 0, Name = "Ruined Style Helm (F) [RL]",   X = 20, Y = 30, Size = "1.2"},
        {Price = 5000, ItemIndex = GET_ITEM(08, 285), Level = 15, Dur = 255, Skill = 0, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 0, Name = "Ruined Style Armor (F) [RL]",  X = 20, Y = 34, Size = "1.2"},
        {Price = 5000, ItemIndex = GET_ITEM(09, 285), Level = 15, Dur = 255, Skill = 0, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 0, Name = "Ruined Style Pants (F) [RL]",  X = 20, Y = 25, Size = "1.2"},
        {Price = 5000, ItemIndex = GET_ITEM(10, 285), Level = 15, Dur = 255, Skill = 0, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 0, Name = "Ruined Style Gloves (F) [RL]", X = 20, Y = 32, Size = "1.2"},
        {Price = 5000, ItemIndex = GET_ITEM(11, 285), Level = 15, Dur = 255, Skill = 0, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 0, Name = "Ruined Style Boots (F) [RL]",  X = 20, Y = 35, Size = "1.2"},

        {Price = 5000, ItemIndex = GET_ITEM(00, 147), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 0, Name = "Ruined Style Sword [RL]",      X = 23, Y = 38, Size = "1.4"},
        {Price = 5000, ItemIndex = GET_ITEM(01, 102), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 0, Name = "Ruined Style Spear [RL]",      X = 23, Y = 38, Size = "1.2"},
        {Price = 5000, ItemIndex = GET_ITEM(04, 104), Level = 15, Dur = 255, Skill = 0, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 0, Name = "Ruined Style Bow [RL]",        X = 25, Y = 38, Size = "1.2"},
        {Price = 5000, ItemIndex = GET_ITEM(05, 121), Level = 15, Dur = 255, Skill = 0, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 0, Name = "Ruined Style Staff [RL]",      X = 23, Y = 20, Size = "1.2"},
        {Price = 5000, ItemIndex = GET_ITEM(06, 122), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 0, Name = "Ruined Style Shield [RL]",     X = 22, Y = 31, Size = "1.2"},

        {Price = 5000, ItemIndex = GET_ITEM(12, 381), Level = 15, Dur = 255, Skill = 0, Luck = 1, Opt = 7, Exc = 47, Ancient = 0, Harmony = 0, Name = "Ruined Style Wings [RL]",      X = 20, Y = 25, Size = "1.2"},
        {Price = 5000, ItemIndex = GET_ITEM(12, 382), Level = 15, Dur = 255, Skill = 0, Luck = 1, Opt = 7, Exc = 47, Ancient = 0, Harmony = 0, Name = "Ruined Style Cape [RL]",       X = 22, Y = 29, Size = "1.0"},
    }

}

return FragmentStore_Config