-----------------------------------------
-----------------------------------------

ROLETAPREMIUM_SWITCH				= 1						-- Ativa/Desativa o comando
ROLETAPREMIUM_COMMAND				= "/roleta"		-- Comando digitado pelo player
ROLETAPREMIUM_TABLE					= "CashShopData"			-- Tabela da moeda
ROLETAPREMIUM_WHERE					= "AccountID"			-- Identificador do player
ROLETAPREMIUM_COLUMN				= "WcoinC"				-- Coluna da moeda
ROLETAPREMIUM_NAME					= "Cash"				-- Nome da moeda
ROLETAPREMIUM_PRICE					= 1000						-- Pre�o para executar o comando
ROLETAPREMIUM_PORCENTAGEM_SWITCH	= 1						-- Ativa/Desativa sistema de porcentagem

--## ATEN��O!  A porcentagem de todos os itens/moedas somados n�o deve exceder 100 ##--

--[[
Type:
0 = Item normal
1 = Set - Coloque somente o Helm no Index
2 = Kit Aneis - Coleque o Pendant no Index e o Ring no ExtraIndex
3 = Kit Sword/Mace - Coloque a Sword/Mace no Index e o Shield no ExtraIndex
4 = Troll - Player n�o recebe nada
5 = Moeda identificada pelo Login
6 = Moeda identificada pelo Nick
]]

--## PREMIO EM MOEDA ##--

ROLETAPREMIUM_COINS = {
}

--## PREMIO EM ITEM ##--

ROLETAPREMIUM_ITENS = {
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-- 

{
_Name			= "BOX Armageddon",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 7410,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 0,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 0,	-- Durabilidade
_Skill			= 0,	-- Skill
_Opt			= 0,	-- Option
_Exc			= 0,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.50,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},
{
_Name			= "BOX Armageddon",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 7410,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 0,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 0,	-- Durabilidade
_Skill			= 0,	-- Skill
_Opt			= 0,	-- Option
_Exc			= 0,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.50,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},
{
_Name			= "BOX Armageddon",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 7410,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 0,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 0,	-- Durabilidade
_Skill			= 0,	-- Skill
_Opt			= 0,	-- Option
_Exc			= 0,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.50,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},




{
_Name			= "Sword Necronamcer",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 86,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.06,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Shield Necronamcer",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 3302,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.10,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Helm Necronamcer",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 3829,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.10,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Armor Necronamcer",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 4341,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.08,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Pants Necronamcer",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 4853,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.10,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Gloves Necronamcer",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 5365,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.10,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Boots Necronamcer",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 5877,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.07,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Asa Necronamcer",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 6398,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.03,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Capa Necronamcer",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 6399,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.05,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Brinco [R] Necronamcer",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 8080,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.04,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Brinco [L] Necronamcer",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 8081,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.02,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Asa Armageddon",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 6408,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.02,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Ring Armageddon",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 8089,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.02,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Pend Armageddon",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 8090,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.02,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 1,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Helm Of God 2.0 [RL]",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 3794,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.40,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 0,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},
{
_Name			= "Armor Of God 2.0 [RL]",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 4306,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.80,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 0,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},
{
_Name			= "Pants Of God 2.0 [RL]",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 4818,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.40,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 0,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},
{
_Name			= "Gloves Of God 2.0 [RL]",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 5330,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.40,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 0,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia

},
{
_Name			= "Boots Of God 2.0 [RL]",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 5842,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.40,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 0,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia

},


{
_Name			= "TROLL",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 7735,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.50,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 0,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Sword God 2.0 [RL]",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 52,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.40,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 0,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},
{
_Name			= "Shield God 2.0 [RL]",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 3281,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.40,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 0,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},
{
_Name			= "Wing God 2.0 [RL]",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 6359,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.40,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 0,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},
{
_Name			= "Capa God 2.0 [RL]",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 6360,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.40,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 0,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},
{
_Name			= "Ring God 2.0 [RL]",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 6809,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.40,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 0,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},

{
_Name			= "Pend God 2.0 [RL]",	-- Nome do Item
_Type			= 0,	-- Tipo
_Index			= 6810,	-- Index do item (section * 512 + index)
_ExtraIndex		= 0,	-- Index do item que vira junto caso Type = 2 ou 3 (section * 512 + index)
_Level			= 15,	-- Level
_Durabilidade	= 255,	-- Sorte
_Luck			= 1,	-- Durabilidade
_Skill			= 1,	-- Skill
_Opt			= 7,	-- Option
_Exc			= 63,	-- Option excelente
_Count			= 1,	-- Quantidade
_Porcentagem	= 0.40,	-- Porcentagem do item - Minimo 0.01 m�ximo 100
_AnuncioGlobal	= 0,	-- 1 Anuncia no global qual item ganhou, 0 n�o anuncia
},



}