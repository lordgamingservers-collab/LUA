kingSwitch = false

kingShowEnterPlayer = true

kingPVPUseQuery = false

kingPVPDataBase = {
    table = "Character",
    where = "ReiDoPVP"
}

infosKingPVP = {
    nome = "              M",
    level =           400,
    agilidade =      32767,
    energia =        32767,
    vida =            32767,
    forca =           32767,
    comando =         32767,
    masterReset =     100,
    reset =           0,
}