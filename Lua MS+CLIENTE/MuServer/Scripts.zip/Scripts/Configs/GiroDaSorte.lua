GiroDaSorte_Config = {
    Enabled = true,

    Packet = 43,

    Npc = {
        {Class = 710, Map = 0, PosX = 130, PosY = 129},
    },

    Moedas = {
        [1] = {Nome = "Cashs",		Tabela = "MEMB_INFO", Coluna = "cash",	 Where = "memb___id", IdType = 0},
        [2] = {Nome = "Golds",		Tabela = "MEMB_INFO", Coluna = "gold",	 Where = "memb___id", IdType = 0},
        [3] = {Nome = "PCPoints",	Tabela = "MEMB_INFO", Coluna = "PCPoint", Where = "memb___id", IdType = 0},
    },

    Pacotes = {                                                              
        {IndexPacote = 01, Nome = "Pacote 01: Clássicos",		Custo = 1, UseRate = true, 	Disponibilidade = "-",	ArcPoints = 1},
        {IndexPacote = 02, Nome = "Pacote 02: Especiais",	    Custo = 2, UseRate = false, Disponibilidade = "-",	ArcPoints = 2},
        {IndexPacote = 03, Nome = "Pacote 03: Promoção",	    Custo = 3, UseRate = true, 	Disponibilidade = "-",	ArcPoints = 1},
    },

    Custo = {
        [1] = {
            {Moeda = 1, Valor = 100},
        },
        [2] = {
            {Moeda = 2, Valor = 1},
        },
        [3] = {
            {Moeda = 3, Valor = 1},

        },
    },

    Itens = {
        [1] = {
			-- ItemIndex = 20000 troll
            {ListID = 01, ItemIndex = 20000,           Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "90", PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 02, ItemIndex = GET_ITEM(7, 0),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 03, ItemIndex = GET_ITEM(8, 0),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 04, ItemIndex = GET_ITEM(9, 0),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 05, ItemIndex = GET_ITEM(10, 0), Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 06, ItemIndex = GET_ITEM(11, 0), Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 07, ItemIndex = GET_ITEM(7, 1),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 08, ItemIndex = GET_ITEM(8, 1),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "2",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 09, ItemIndex = GET_ITEM(9, 1),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "2",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 10, ItemIndex = GET_ITEM(10, 1), Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "2",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 11, ItemIndex = GET_ITEM(11, 1), Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "2",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
        },

        [2] = {
            -- ItemIndex = 20000 troll
            {ListID = 01, ItemIndex = 20000,           Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "90", PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 02, ItemIndex = GET_ITEM(7, 0),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 03, ItemIndex = GET_ITEM(8, 0),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 04, ItemIndex = GET_ITEM(9, 0),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 05, ItemIndex = GET_ITEM(10, 0), Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 06, ItemIndex = GET_ITEM(11, 0), Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 07, ItemIndex = GET_ITEM(7, 1),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 08, ItemIndex = GET_ITEM(8, 1),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "2",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 09, ItemIndex = GET_ITEM(9, 1),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "2",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 10, ItemIndex = GET_ITEM(10, 1), Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "2",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 11, ItemIndex = GET_ITEM(11, 1), Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "2",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
        },
	   --},
        [3] = {
            -- ItemIndex = 20000 troll
            {ListID = 01, ItemIndex = 20000,           Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "90", PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 02, ItemIndex = GET_ITEM(7, 0),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 03, ItemIndex = GET_ITEM(8, 0),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 04, ItemIndex = GET_ITEM(9, 0),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 05, ItemIndex = GET_ITEM(10, 0), Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 06, ItemIndex = GET_ITEM(11, 0), Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 07, ItemIndex = GET_ITEM(7, 1),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "3",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 08, ItemIndex = GET_ITEM(8, 1),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "2",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 09, ItemIndex = GET_ITEM(9, 1),  Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "2",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 10, ItemIndex = GET_ITEM(10, 1), Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "2",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
            {ListID = 11, ItemIndex = GET_ITEM(11, 1), Level = 15, Dur = 255, Skill = 1, Luck = 1, JoL = 7, Exc = 63, Days = 0, Rate = "2",  PosX = "-09", PosY = "00", Width = "60", Height = "50", Size = "0.8"},
	   },
    }
}

return GiroDaSorte_Config