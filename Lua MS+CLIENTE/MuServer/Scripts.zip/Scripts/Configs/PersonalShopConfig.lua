Coin1Switch = 1
Coin2Switch = 1
Coin3Switch = 1
Coin4Switch = 0

--[[
Coin1 para Coin3 por padr�o puxa Cash Cash e GlobinPoint
    Se voc� definir J�ia = 1, a moeda pedir� a joia que voc� determinar!
    Identifica��o � a identifica��o da joia em rela��o ao JewelBank na fun��o CacheName
]]

PERSONAL_SHOP_COIN1_JEWEL = 0
PERSONAL_SHOP_COIN1_IDENTIFICATION = "WcoinC"

PERSONAL_SHOP_COIN2_JEWEL = 0
PERSONAL_SHOP_COIN2_IDENTIFICATION = "WcoinP"


PERSONAL_SHOP_COIN3_JEWEL = 0
PERSONAL_SHOP_COIN3_IDENTIFICATION = "HorasOn"

PERSONAL_SHOP_COIN4_JEWEL = 0
PERSONAL_SHOP_COIN4_IDENTIFICATION = "Cashs"

PERSONAL_SHOP_MESSAGES = {}

PERSONAL_SHOP_MESSAGES['Por'] = {
[1] = "Foi adicionado %d Cash por sua venda",
[2] = "Foi adicionado %d Golds por sua venda",
[3] = "Foi adicionado %d Horas por sua venda",
[4] = "Foi adicionado %d Cash por sua venda",
[5] = "Foi retirado %d Cash por sua compra",
[6] = "Foi retirado %d Golds por sua compra",
[7] = "Foi retirado %d Horas por sua compra",
[8] = "Foi retirado %d Cash por sua compra",
[9] = "Voc� precisa ter %d Cash para comprar esse item",
[10] = "Voc� precisa ter %d Golds para comprar esse item",
[11] = "Voc� precisa ter %d Horas para comprar esse item",
[12] = "Voc� precisa ter %d Cash para comprar esse item",
}

PERSONAL_SHOP_MESSAGES['Eng'] = {
[1] = "Foi adicionado %d Cash por sua venda",
[2] = "Foi adicionado %d Golds por sua venda",
[3] = "Foi adicionado %d Horas por sua venda",
[4] = "Foi adicionado %d Cash por sua venda",
[5] = "Foi retirado %d Cash por sua compra",
[6] = "Foi retirado %d Golds por sua compra",
[7] = "Foi retirado %d Horas por sua compra",
[8] = "Foi retirado %d Cash por sua compra",
[9] = "Voc� precisa ter %d Cash para comprar esse item",
[10] = "Voc� precisa ter %d Golds para comprar esse item",
[11] = "Voc� precisa ter %d Horas para comprar esse item",
[12] = "Voc� precisa ter %d Cash para comprar esse item",
}

PERSONAL_SHOP_MESSAGES['Spn'] = {
[1] = "Foi adicionado %d Cash por sua venda",
[2] = "Foi adicionado %d Golds por sua venda",
[3] = "Foi adicionado %d Horas por sua venda",
[4] = "Foi adicionado %d Cash por sua venda",
[5] = "Foi retirado %d Cash por sua compra",
[6] = "Foi retirado %d Golds por sua compra",
[7] = "Foi retirado %d Horas por sua compra",
[8] = "Foi retirado %d Cash por sua compra",
[9] = "Voc� precisa ter %d Cash para comprar esse item",
[10] = "Voc� precisa ter %d Golds para comprar esse item",
[11] = "Voc� precisa ter %d Horas para comprar esse item",
[12] = "Voc� precisa ter %d Cash para comprar esse item",
}
