TIMER_EVENTS_SWITCH = 0

TIMER_EVENTS_PACKET = 5
TIMER_EVENTS_PACKET_NAME = 'TIMER_EVENTS_PACKET_OPEN'

--precisa aumentar aqui se tiver mais eventos
TIMER_EVENTS_COUNT = 3

TIMER_EVENTS_INFO = {}


TIMER_EVENTS_INFO[1] = {
    { dayOfWeek = -1, day = -1, hour = 00,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 01,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 02,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 03,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 04,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 05,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 06,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 07,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 08,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 09,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 10,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 11,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 12,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 13,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 14,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 15,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 16,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 17,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 18,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 19,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 20,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 21,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 22,  minute = 59, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 23,  minute = 59, second = 0, tickTime = -1 },

}

TIMER_EVENTS_INFO[2] = {
    { dayOfWeek = -1, day = -1, hour = 00,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 01,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 02,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 03,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 04,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 05,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 06,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 07,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 08,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 09,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 10,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 11,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 12,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 13,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 14,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 15,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 16,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 17,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 18,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 19,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 20,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 21,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 22,  minute = 30, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 23,  minute = 30, second = 0, tickTime = -1 },

}

TIMER_EVENTS_INFO[3] = {
    { dayOfWeek = -1, day = -1, hour = 12,  minute = 06, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 12,  minute = 10, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 12,  minute = 13, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 12,  minute = 15, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 12,  minute = 20, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 12,  minute = 23, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 12,  minute = 28, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 12,  minute = 37, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 12,  minute = 43, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 12,  minute = 49, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 12,  minute = 54, second = 0, tickTime = -1 },

    { dayOfWeek = -1, day = -1, hour = 16,  minute = 06, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 16,  minute = 10, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 16,  minute = 13, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 16,  minute = 15, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 16,  minute = 20, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 16,  minute = 23, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 16,  minute = 28, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 16,  minute = 37, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 16,  minute = 43, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 16,  minute = 49, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 16,  minute = 54, second = 0, tickTime = -1 },

    { dayOfWeek = -1, day = -1, hour = 20,  minute = 06, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 20,  minute = 10, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 20,  minute = 13, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 20,  minute = 15, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 20,  minute = 20, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 20,  minute = 23, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 20,  minute = 28, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 20,  minute = 37, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 20,  minute = 43, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 20,  minute = 49, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 20,  minute = 54, second = 0, tickTime = -1 },

    { dayOfWeek = -1, day = -1, hour = 00,  minute = 06, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 00,  minute = 10, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 00,  minute = 13, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 00,  minute = 15, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 00,  minute = 20, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 00,  minute = 23, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 00,  minute = 28, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 00,  minute = 37, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 00,  minute = 43, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 00,  minute = 49, second = 0, tickTime = -1 },
    { dayOfWeek = -1, day = -1, hour = 00,  minute = 54, second = 0, tickTime = -1 },

}