STORE_SEARCH_SWITCH = 0

STORE_SEARCH_ITEM_LIST_PACKET_NAME = 'StoreSearchGetItemList'
STORE_SEARCH_ITEM_BUY_PACKET_NAME = 'StoreSearchBuyItem'
STORE_SEARCH_PACKET_NAME = 'StoreSearch'
STORE_SEARCH_PACKET_FIND_ITEM_NAME = 'StoreSearchFindItem'
STORE_SEARCH_PACKET_BUY_FIND_ITEM_NAME = 'StoreSearchBuyFindItem'
STORE_SEARCH_PACKET = 0x04

STORE_SEARCH_MESSAGES = {}

STORE_SEARCH_MESSAGES['Por'] = {
[1] = 'Voc� est� ocupado no momento!',
[2] = 'O Jogador alvo n�o est� online!',
[3] = 'Ocorreu algum problema ao identificar o jogador alvo!',
[4] = 'A loja deste jogador n�o existe!',
[5] = 'Este item n�o existe na lojinha!',
}

STORE_SEARCH_MESSAGES['Eng'] = {
[1] = 'Voc� est� ocupado no momento!',
[2] = 'O Jogador alvo n�o est� online!',
[3] = 'Ocorreu algum problema ao identificar o jogador alvo!',
[4] = 'A loja deste jogador n�o existe!',
[5] = 'Este item n�o existe na lojinha!',
}

STORE_SEARCH_MESSAGES['Spn'] = {
[1] = 'Voc� est� ocupado no momento!',
[2] = 'O Jogador alvo n�o est� online!',
[3] = 'Ocorreu algum problema ao identificar o jogador alvo!',
[4] = 'A loja deste jogador n�o existe!',
[5] = 'Este item n�o existe na lojinha!',
}