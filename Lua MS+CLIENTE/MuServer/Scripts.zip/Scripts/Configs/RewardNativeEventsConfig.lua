
REWARD_NATIVE_EVENTS_SWITCH = 0

REWARD_NATIVE_EVENTS_COINS = {}

--Type 1 = BC, 2 = CC, 3 = DS

--BC
REWARD_NATIVE_EVENTS_COINS[1] = {
 --{ Table = 'MEMB_INFO', Column = 'cash', Where = 'memb___id', Name = 'cash', Amount = 300 },
}

--CC
REWARD_NATIVE_EVENTS_COINS[2] = {
 --{ Table = 'CashShopItem', Column = 'WCoinP', Where = 'AccountID', Name = 'WCoinP', Amount = 5 },
 --{ Table = 'CashShopItem', Column = 'WCoinC', Where = 'AccountID', Name = 'WCoinC', Amount = 5 },
}

--DS
REWARD_NATIVE_EVENTS_COINS[3] = {
 -- Table = 'CashShopItem', Column = 'WCoinP', Where = 'AccountID', Name = 'WCoinP', Amount = 5 },
 -- Table = 'CashShopItem', Column = 'WCoinC', Where = 'AccountID', Name = 'WCoinC', Amount = 5 },
}

--[[
Configura��o de recompensa de Itens (somente em resgate de NPC)
]]--
REWARD_NATIVE_EVENTS_ITENS = {}

--BC


--[[
Messages Configs
]]--
REWARD_NATIVE_EVENTS_MESSAGES = {}

REWARD_NATIVE_EVENTS_MESSAGES['Por'] = {
[1] = 'Voc� ganhou %d %s em sua conta!',
[2] = 'Voc� ganhou o item %d %s, resgate no Npc Rescue!',
}

REWARD_NATIVE_EVENTS_MESSAGES['Eng'] = {
[1] = 'Voc� ganhou %d %s em sua conta!',
[2] = 'Voc� ganhou o item %d %s, resgate no Npc Rescue!',
}

REWARD_NATIVE_EVENTS_MESSAGES['Spn'] = {
[1] = 'Voc� ganhou %d %s em sua conta!',
[2] = 'Voc� ganhou o item %d %s, resgate no Npc Rescue!',
}
