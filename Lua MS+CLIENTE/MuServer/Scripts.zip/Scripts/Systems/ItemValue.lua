ITEM_VALUE_AMOUNT = {}

ITEM_VALUE_AMOUNT[1] = { Table = 'CashShopData', Column = 'WCoinC', Where = 'AccountID' }
ITEM_VALUE_AMOUNT[2] = { Table = 'CashShopData', Column = 'WCoinP', Where = 'AccountID' }
ITEM_VALUE_AMOUNT[3] = { Table = 'CashShopData', Column = 'GoblinPoint', Where = 'AccountID' }


ITEM_VALUE_MESSAGES = {}

ITEM_VALUE_MESSAGES['Por'] = {
[1] = "voc� n�o possui %d Dimas suficientes!",
[2] = "voc� n�o possui %d Gold suficientes!",
[3] = "voc� n�o possui %d GoblinPoint suficientes!",
[4] = "voc� recebeu por sua venda %d Dimas",
[5] = "voc� recebeu por sua venda %d Gold",
[6] = "voc� recebeu por sua venda %d GoblinPoint",
[7] = "foi debitado %d Dimas da sua conta",
[8] = "foi debitado %d Gold da sua conta",
[9] = "foi debitado %d GoblinPoint da sua conta",
}

ITEM_VALUE_MESSAGES['Eng'] = {
[1] = "You don't have enough %d Dimas!",
[2] = "you don't have enough %d Gold!",
[3] = "You don't have enough %d GoblinPoint!",
[4] = "you received for your sale %d Dimas",
[5] = "you received for your sale %d Gold",
[6] = "you received for your sale %d GoblinPoint",
[7] = "%d Dimas has been debited from your account",
[8] = "%d Gold has been debited from your account",
[9] = "%d GoblinPoint has been debited from your account",
}

ITEM_VALUE_MESSAGES['Spn'] = {
[1] = "�No tienes suficiente %d Dimas!",
[2] = "�no tienes suficiente %d Gold!",
[3] = "�No tienes suficiente %d GoblinPoint!",
[4] = "recibi� por su venta %d Dimas",
[5] = "recibi� por su venta %d Gold",
[6] = "recibiste por tu venta %d GoblinPoint",
[7] = "Se debit� %d Dimas de su cuenta",
[8] = "Se debit� %d Gold de su cuenta",
[9] = "Se debit� %d GoblinPoint de su cuenta",
}

ItemValue = { }

function ItemBuyCheckCoins(aIndex, Coin1, Coin2, Coin3)
	local player = User.new(aIndex)
	
	local Coin1Check = 0
	local Coin2Check = 0
	local Coin3Check = 0
	
	if Coin1 > 0
	then
		Coin1Check = DataBase.GetValue(ITEM_VALUE_AMOUNT[1].Table, ITEM_VALUE_AMOUNT[1].Column, ITEM_VALUE_AMOUNT[1].Where, player:getAccountID())
	end
	
	if Coin2 > 0
	then
		Coin2Check = DataBase.GetValue(ITEM_VALUE_AMOUNT[2].Table, ITEM_VALUE_AMOUNT[2].Column, ITEM_VALUE_AMOUNT[2].Where, player:getAccountID())
	end
	
	if Coin3 > 0
	then
		Coin3Check = DataBase.GetValue(ITEM_VALUE_AMOUNT[3].Table, ITEM_VALUE_AMOUNT[3].Column, ITEM_VALUE_AMOUNT[3].Where, player:getAccountID())
	end
	
	player = nil
	
	return Coin1Check, Coin2Check, Coin3Check
end

function ItemBuyDecreaseCoins(aIndex, Coin1, Coin2, Coin3)
	local player = User.new(aIndex)
	local Language = player:getLanguage()
	
	if Coin1 > 0
	then
		DataBase.SetDecreaseValue(ITEM_VALUE_AMOUNT[1].Table, ITEM_VALUE_AMOUNT[1].Column, Coin1, ITEM_VALUE_AMOUNT[1].Where, player:getAccountID())
		SendMessage(string.format(ITEM_VALUE_MESSAGES[Language][7], Coin1), aIndex, 1)
	end
	
	if Coin2 > 0
	then
		DataBase.SetDecreaseValue(ITEM_VALUE_AMOUNT[2].Table, ITEM_VALUE_AMOUNT[2].Column, Coin2, ITEM_VALUE_AMOUNT[2].Where, player:getAccountID())
		SendMessage(string.format(ITEM_VALUE_MESSAGES[Language][8], Coin2), aIndex, 1)
	end
	
	if Coin3 > 0
	then
		DataBase.SetDecreaseValue(ITEM_VALUE_AMOUNT[3].Table, ITEM_VALUE_AMOUNT[3].Column, Coin3, ITEM_VALUE_AMOUNT[3].Where, player:getAccountID())
		SendMessage(string.format(ITEM_VALUE_MESSAGES[Language][9], Coin3), aIndex, 1)
	end
	
	player = nil
end

function ItemSellAddCoins(aIndex, Coin1, Coin2, Coin3)
	local player = User.new(aIndex)
	local Language = player:getLanguage()
	
	if Coin1 > 0
	then
		DataBase.SetAddValue(ITEM_VALUE_AMOUNT[1].Table, ITEM_VALUE_AMOUNT[1].Column, Coin1, ITEM_VALUE_AMOUNT[1].Where, player:getAccountID())
		SendMessage(string.format(ITEM_VALUE_MESSAGES[Language][4], Coin1), aIndex, 1)
	end
	
	if Coin2 > 0
	then
		DataBase.SetAddValue(ITEM_VALUE_AMOUNT[2].Table, ITEM_VALUE_AMOUNT[2].Column, Coin2, ITEM_VALUE_AMOUNT[2].Where, player:getAccountID())
		SendMessage(string.format(ITEM_VALUE_MESSAGES[Language][5], Coin2), aIndex, 1)
	end
	
	if Coin3 > 0
	then
		DataBase.SetAddValue(ITEM_VALUE_AMOUNT[3].Table, ITEM_VALUE_AMOUNT[3].Column, Coin3, ITEM_VALUE_AMOUNT[3].Where, player:getAccountID())
		SendMessage(string.format(ITEM_VALUE_MESSAGES[Language][6], Coin3), aIndex, 1)
	end
	
	player = nil
end

function ItemBuyBuyError(aIndex, CoinsNeed, Coin)
	local player = User.new(aIndex)
	local Language = player:getLanguage()
	
	SendMessage(string.format(ITEM_VALUE_MESSAGES[Language][Coin], CoinsNeed), aIndex, 1)
	
	player = nil
end

return ItemValue