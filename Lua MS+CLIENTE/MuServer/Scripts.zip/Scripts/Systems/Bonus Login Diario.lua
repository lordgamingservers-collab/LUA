BonusLogin = {}

function BonusLogin.Init()
		
	if not BonusLogin_Ativado then return end
	
	GameServerFunctions.EnterCharacter(BonusLogin.EnterCharacter)
end

function BonusLogin.EnterCharacter(aIndex)
	local player = User.new(aIndex)
	local tipo = ""
	if BonusLogin_SqlConfig.Tipo == 0 then
		tipo = player:getAccountID()
	else
		tipo = player:getName()
	end
	local recebido = DataBase.GetValue(BonusLogin_SqlConfig.Tabela, BonusLogin_SqlConfig.ColunaRecebido, BonusLogin_SqlConfig.Where, tipo)
	
	if recebido == 0 then
		local diasConsecutivos = DataBase.GetValue(BonusLogin_SqlConfig.Tabela, BonusLogin_SqlConfig.Coluna, BonusLogin_SqlConfig.Where, tipo)
	
		diasConsecutivos = diasConsecutivos + 1
		
		if diasConsecutivos > BonusLogin_MaximoDias then
			diasConsecutivos = 1
		end
		
		if diasConsecutivos == 1 then
			SendMessage(string.format("Voc� logou %d dia seguido", diasConsecutivos), aIndex, 1)
		else
			SendMessage(string.format("Voc� logou %d dias seguidos", diasConsecutivos), aIndex, 1)
		end
		
		for i in ipairs(BonusLogin_PremioMoeda) do
			if BonusLogin_PremioMoeda[i].Dia == diasConsecutivos then
				local tipo2 = ""
				if BonusLogin_PremioMoeda[i].Tipo == 0 then
					tipo2 = player:getAccountID()
				else
					tipo2 = player:getName()
				end
				DataBase.SetAddValue(BonusLogin_PremioMoeda[i].Tabela, BonusLogin_PremioMoeda[i].Coluna, BonusLogin_PremioMoeda[i].Valor, BonusLogin_PremioMoeda[i].Where, tipo2)
				SendMessage(string.format("Voc� recebeu %d %s", BonusLogin_PremioMoeda[i].Valor, BonusLogin_PremioMoeda[i].Nome), aIndex, 1)
			end
		end
		
		for i in ipairs(BonusLogin_PremioItem) do
			if BonusLogin_PremioItem[i].Dia == diasConsecutivos then
				for qtd = 1, BonusLogin_PremioItem[i].Quantidade do
					if BonusLogin_PremioItem[i].Tempo > 0 then
						ItemSerialCreatePeriodic(aIndex, 236, 0, 0, GET_ITEM(BonusLogin_PremioItem[i].Section, BonusLogin_PremioItem[i].Index), BonusLogin_PremioItem[i].Level, BonusLogin_PremioItem[i].Dur, BonusLogin_PremioItem[i].Skill, BonusLogin_PremioItem[i].Luck, BonusLogin_PremioItem[i].Opt, BonusLogin_PremioItem[i].Exc, BonusLogin_PremioItem[i].Tempo)
					else
						ItemSerialCreate(aIndex, 236, 0, 0, GET_ITEM(BonusLogin_PremioItem[i].Section, BonusLogin_PremioItem[i].Index), BonusLogin_PremioItem[i].Level, BonusLogin_PremioItem[i].Dur, BonusLogin_PremioItem[i].Skill, BonusLogin_PremioItem[i].Luck, BonusLogin_PremioItem[i].Opt, BonusLogin_PremioItem[i].Exc)
					end
				end
				SendMessage(string.format("Voc� recebeu %d %s", BonusLogin_PremioItem[i].Quantidade, BonusLogin_PremioItem[i].Nome), aIndex, 1)
			end
		end
		
		DataBase.SetValue(BonusLogin_SqlConfig.Tabela, BonusLogin_SqlConfig.Coluna, diasConsecutivos, BonusLogin_SqlConfig.Where, tipo)
		DataBase.SetValue(BonusLogin_SqlConfig.Tabela, BonusLogin_SqlConfig.ColunaRecebido, 1, BonusLogin_SqlConfig.Where, tipo)	
	end
end

BonusLogin.Init()

return BonusLogin