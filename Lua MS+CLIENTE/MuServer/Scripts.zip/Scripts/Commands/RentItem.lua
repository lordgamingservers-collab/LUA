RentItem = {}


function RentItem.Init()
	if RentItem_Config.Enabled then
		Commands.Register(RentItem_Config.Command["Eng"], RentItem.Command)
		Commands.Register(RentItem_Config.Command["Por"], RentItem.Command)
		Commands.Register(RentItem_Config.Command["Spn"], RentItem.Command)
	end
end

function RentItem.Command(aIndex, Arguments)
	local player = User.new(aIndex)
	local pInv = Inventory.new(aIndex)
	local vip = player:getVip()
	local lang = player:getLanguage()
	local playerInfo = {[0] = player:getAccountID(), [1] = player:getName()}
	if player:getInterfaceUse() ~= 0 or player:getInterfaceType() ~= 0 or player:getTeleport() ~= 0 or player:getDieRegen() ~= 0 then
		return
	end
	for slot = 12, 75 do
		if pInv:isItem(slot) ~= 0 then
			SendMessage(RentItem_Config.Message[lang][3], aIndex, 1)
			return
		end
	end

	local str = string.sub(string.lower(command:getString(Arguments, 1, 1)),2)

	if RentItem_Config.Item[str] == nil or RentItem_Config.Result[str] == nil then
		SendMessage(RentItem_Config.Message[lang][1], aIndex, 1)
		return
	end

	local item = {Config = RentItem_Config.Item[str], Result = RentItem_Config.Result[str]}

	if item.Config.Vip[vip] == nil or not item.Config.Vip[vip] then
		SendMessage(RentItem_Config.Message[lang][4], aIndex, 1)
		return
	end

	local coin = RentItem_Config.Coin[item.Config.Coin]

	local balance = DataBase.GetValue(coin.Table, coin.Column, coin.Where, playerInfo[coin.IdType])

	if balance < item.Config.Price then
		SendMessage(string.format(RentItem_Config.Message[lang][2], item.Config.Price, coin.Name), aIndex, 1)
		return
	end

	DataBase.SetDecreaseValue(coin.Table, coin.Column, item.Config.Price, coin.Where, playerInfo[coin.IdType])

	for x in ipairs(item.Result) do
		local i = item.Result[x]

		CreateItemInventory(aIndex, GET_ITEM(i.Section, i.Index), i.Level, i.Op1, i.Op2, i.Life, i.Exc, i.Ancient, i.JoH, i.SocketBonus, i.Sock1, i.Sock2, i.Sock3, i.Sock4, i.Sock5, i.TimeExpire)
	end

	SendMessage(string.format(RentItem_Config.Message[lang][5], item.Config.Name, item.Config.Price, coin.Name), aIndex, 1)
	
	return
end

RentItem.Init()

return RentItem