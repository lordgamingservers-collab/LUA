ExchangeItem = {}

function ExchangeItem.Init()
    if ExchangeItem_Config.Enabled then
        Commands.Register(ExchangeItem_Config.Command["Eng"], ExchangeItem.Command)
        Commands.Register(ExchangeItem_Config.Command["Por"], ExchangeItem.Command)
        Commands.Register(ExchangeItem_Config.Command["Spn"], ExchangeItem.Command)
    end
end

function ExchangeItem.Command(aIndex, Arguments)
    local player = User.new(aIndex)
    local pInv = Inventory.new(aIndex)
    local lang = player:getLanguage()
    local playerInfo = {[0] = player:getAccountID(), [1] = player:getName()}
    local str = string.sub(string.lower(command:getString(Arguments, 1, 1)),2)
    
    if player:getInterfaceUse() ~= 0 or player:getInterfaceType() ~= 0 or player:getTeleport() ~= 0 or player:getDieRegen() ~= 0 then
		return
	end

    if ExchangeItem_Config.Item[str] == nil then
        SendMessage(ExchangeItem_Config.Message[lang][1], aIndex, 1)
        return
    end

    local item = ExchangeItem_Config.Item[str]
    local count = 0

    for slot = 12, 139 do
		if pInv:isItem(slot) ~= 0 then
			if pInv:getIndex(slot) == GET_ITEM(item.Section, item.Index) then
                if item.Level == -1 or pInv:getlvel(slot) == item.Level then
                    if GetStackItem(pInv:getIndex(slot)) ~= 0 then
			        	count = count + pInv:getDurability(slot)
			        else
			        	count = count + 1
			        end
                end
            end
		end
	end

    if count <= 0 then
        SendMessage(string.format(ExchangeItem_Config.Message[lang][3], item.Name), aIndex, 1)
		return
    end

    if ExchangeItem_Config.Coin[item.Coin] == nil then
        LogAddC(2, string.format("[Exchange Item] Bad config on item %s", item.Name))
        return
    end

    local coin =  ExchangeItem_Config.Coin[item.Coin]

    DeleteItemCount(aIndex, GET_ITEM(item.Section, item.Index), item.Level, count)

    local amount = count * item.Value

    DataBase.SetAddValue(coin.Table, coin.Column, amount, coin.Where, playerInfo[coin.IdType])

    SendMessage(string.format(ExchangeItem_Config.Message[lang][2], count, item.Name, amount, coin.Name), aIndex, 1)
    return
end

ExchangeItem.Init()

return ExchangeItem