--[[Moves Customs]]--

MoveSystem = {}

SerializeMoves = {}

function MoveSystem.Serialize()
	for i in ipairs(MOVES_CUSTOMS) do
		local move = MOVES_CUSTOMS[i]

		SerializeMoves[move.Move] = { Identification = i }
	end
end

function MoveSystem.CheckMove(aIndex, Command, Arguments)
	local getMove = SerializeMoves[Command]

	if getMove ~= nil
	then
		local move = MOVES_CUSTOMS[getMove.Identification]

		if move ~= nil
		then
			local player = User.new(aIndex)
			local Language = player:getLanguage()
			local pInv = Inventory.new(aIndex)
			local Name = player:getName()
			
			local vip = player:getVip()
			local Resets = player:getReset()
			local MResets = player:getMasterReset()

			if player:getInterfaceUse() ~= 0 or player:getInterfaceType() ~= 0 or player:getTeleport() ~= 0 or player:getDieRegen() ~= 0
			then
				SendMessage(string.format(MOVE_CUSTOM_MESSAGE[Language][1]), aIndex, 1)
				return 1
			end
		
			if move.MinLevel ~= -1 and player:getLevel() < move.MinLevel
			then
				SendMessage(string.format(MOVE_CUSTOM_MESSAGE[Language][2], move.MinLevel), aIndex, 1)
				return 1
			end
			
			if move.MaxLevel ~= -1 and player:getLevel() > move.MaxLevel
			then
				SendMessage(string.format(MOVE_CUSTOM_MESSAGE[Language][3], move.MaxLevel), aIndex, 1)
				return 1
			end
			
			if move.Map == 10 and pInv:isItem(7) == 0
			then
				if pInv:isItem(8) == 0 or pInv:getIndex(8) ~= GET_ITEM(13, 3) and pInv:getIndex(8)
				then
					SendMessage(string.format(MOVE_CUSTOM_MESSAGE[Language][4]), aIndex, 1)
					return 1
				end
			end
			
			if move.Map == 7 and pInv:isItem(8) ~= 0
			then
				if pInv:getIndex(8) == GET_ITEM(13, 2) or pInv:getIndex(8) == GET_ITEM(13, 3)
				then
					SendMessage(string.format(MOVE_CUSTOM_MESSAGE[Language][5]), aIndex, 1)
					return 1
				end
			end
			
			if vip < move.VipType
			then
				SendMessage(string.format(MOVE_CUSTOM_MESSAGE[Language][6]), aIndex, 1)
				return 1
			end
			
			if player:getMoney() < move.Price
			then
				SendMessage(string.format(MOVE_CUSTOM_MESSAGE[Language][7], move.Price), aIndex, 1)
				return 1
			end
			
			if player:getPKLevel() > 4 and move.Pk == 0
			then
				SendMessage(string.format(MOVE_CUSTOM_MESSAGE[Language][8]), aIndex, 1)
				return 1
			end
			
			if move.MinReset ~= -1 and Resets < move.MinReset
			then
				SendMessage(string.format(MOVE_CUSTOM_MESSAGE[Language][9], move.MinReset), aIndex, 1)
				return 1
			end
			
			if move.MaxReset ~= -1 and Resets > move.MaxReset
			then
				SendMessage(string.format(MOVE_CUSTOM_MESSAGE[Language][10], move.MaxReset), aIndex, 1)
				return 1
			end
			
			if move.MinMReset ~= -1 and MResets < move.MinMReset
			then
				SendMessage(string.format(MOVE_CUSTOM_MESSAGE[Language][11], move.MinMReset), aIndex, 1)
				return 1
			end
			
			if move.MaxMReset ~= -1 and MResets > move.MaxMReset
			then
				SendMessage(string.format(MOVE_CUSTOM_MESSAGE[Language][12], move.MaxMReset), aIndex, 1)
				return 1
			end
			
			local setmoney = player:getMoney() - move.Price
			player:setMoney(setmoney)
			MoneySend(aIndex)
							
			Teleport(aIndex, move.Map, move.CoordX, move.CoordY)
			return 1
		end
	end
		
	return 0
end

if MOVES_CUSTOMS_SWITCH ~= 0
then
	MoveSystem.Serialize()
	Commands.CallCommand(MoveSystem.CheckMove)
end

return MoveSystem