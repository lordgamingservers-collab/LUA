-----------------------------------------
	-- Script:  RoletaPremium
	-- Criador: Pedro Borges
	-- Skype: live:ppborges93
-----------------------------------------

RoletaPremium = {}

function RoletaPremium.Command(aIndex, Arguments)
	if ROLETAPREMIUM_SWITCH == 0
	then
		return
	end
	
	local player = User.new(aIndex)
	local pInv = Inventory.new(aIndex)

	for i = 12, MAX_INVENTORY_RANGE do
		if pInv:isItem(i) ~= 0
		then
			SendMessage(string.format("[Roleta] Seu invent�rio precisa estar vazio!"), aIndex, 1)
			return 
		end
	end
	
	local Account = player:getAccountID()
	
	if DataBase.GetValue(ROLETAPREMIUM_TABLE, ROLETAPREMIUM_COLUMN , ROLETAPREMIUM_WHERE, Account) < ROLETAPREMIUM_PRICE
	then
		SendMessage(string.format("[Roleta] Voce precisa de ao menos %d %s para usar o comando.", ROLETAPREMIUM_PRICE, ROLETAPREMIUM_NAME), aIndex, 1)
		return
	end
	
	SendMessage(string.format("[Sistema] Girando a roleta..."), aIndex, 1)
	Timer.Repeater(2, 0, RoletaPremium.Girando, aIndex)	
end

function RoletaPremium.Girando(aIndex)
	
	local player = User.new(aIndex)

	local Item = RoletaPremium.GetItem()
	local Name = player:getName()
	local Account = player:getAccountID()
	
	if Item == nil
	then 
		SendMessage(string.format("[Roleta] Houve um problema ao usar o comando, tente novamente."), aIndex, 1)
		DataBase.SetAddValue(ROLETAPREMIUM_TABLE, ROLETAPREMIUM_COLUMN, ROLETAPREMIUM_PRICE, ROLETAPREMIUM_WHERE, Account)
		return
	end
	
	if Item == -1
	then
		SendMessage(string.format("[Roleta] Houve um problema ao usar o comando, tente novamente."), aIndex, 1)
		DataBase.SetAddValue(ROLETAPREMIUM_TABLE, ROLETAPREMIUM_COLUMN, ROLETAPREMIUM_PRICE, ROLETAPREMIUM_WHERE, Account)
		return
	end
	
	if Item._Type == 4
	then
		if Item._AnuncioGlobal == 1
		then
			SendMessageGlobal(string.format("[Roleta] %s foi trolado!", Name), 1)
		else	
			SendMessage(string.format("[Roleta] Voc� foi trolado!"), aIndex, 1)
		end
		return
	end
	
	if Item._Type > -1 and Item._Type < 4
	then	
		for forcount = 1, Item._Count do		
			ItemSerialCreate(aIndex, 236, 0, 0, Item._Index, Item._Level, Item._Durabilidade, Item._Luck, Item._Skill, Item._Opt, Item._Exc)
			
			if Item._Type == 1
			then
				local index = Item._Index - 3584
				ItemSerialCreate(aIndex, 236, 0, 0, 4096 + index, Item._Level, Item._Durabilidade, Item._Luck, Item._Skill, Item._Opt, Item._Exc)
				ItemSerialCreate(aIndex, 236, 0, 0, 4608 + index, Item._Level, Item._Durabilidade, Item._Luck, Item._Skill, Item._Opt, Item._Exc)
				ItemSerialCreate(aIndex, 236, 0, 0, 5120 + index, Item._Level, Item._Durabilidade, Item._Luck, Item._Skill, Item._Opt, Item._Exc)
				ItemSerialCreate(aIndex, 236, 0, 0, 5632 + index, Item._Level, Item._Durabilidade, Item._Luck, Item._Skill, Item._Opt, Item._Exc)				
			elseif Item._Type == 2
			then
				ItemSerialCreate(aIndex, 236, 0, 0, Item._ExtraIndex, Item._Level, Item._Durabilidade, Item._Luck, Item._Skill, Item._Opt, Item._Exc)
				ItemSerialCreate(aIndex, 236, 0, 0, Item._ExtraIndex, Item._Level, Item._Durabilidade, Item._Luck, Item._Skill, Item._Opt, Item._Exc)
			elseif Item._Type == 3
			then
				ItemSerialCreate(aIndex, 236, 0, 0, Item._ExtraIndex, Item._Level, Item._Durabilidade, Item._Luck, Item._Skill, Item._Opt, Item._Exc)
			end
		end
		
		if Item._AnuncioGlobal == 1
		then
			SendMessageGlobal(string.format("[Roleta] %s ganhou %d %s!", Name, Item._Count, Item._Name), 1)
		else
			SendMessage(string.format("[Roleta] Voc� ganhou %d %s!", Item._Count, Item._Name), aIndex, 1)
		end
	elseif Item._Type == 5
	then
		DataBase.SetAddValue(Item._Table, Item._Column, Item._Ammount, Item._Where, Account)
		if Item._AnuncioGlobal == 1
		then
			SendMessageGlobal(string.format("[Roleta] %s ganhou %d %s!", Name, Item._Ammount, Item._Name), 1)
		else
			SendMessage(string.format("[Roleta] Voc� ganhou %d %s!", Item._Ammount, Item._Name), aIndex, 1)
		end
	elseif Item._Type == 6
	then
		DataBase.SetAddValue(Item._Table, Item._Column, Item._Ammount, Item._Where, Name)
		if Item._AnuncioGlobal == 1
		then
			SendMessageGlobal(string.format("[Roleta] %s ganhou %d %s!", Name, Item._Ammount, Item._Name), 1)
		else
			SendMessage(string.format("[Roleta] Voc� ganhou %d %s!", Item._Ammount, Item._Name), aIndex, 1)
		end
	end	
	
	DataBase.SetDecreaseValue(ROLETAPREMIUM_TABLE, ROLETAPREMIUM_COLUMN, ROLETAPREMIUM_PRICE, ROLETAPREMIUM_WHERE, Account)
	
	return
end

function RoletaPremium.GetItem()
	if ROLETAPREMIUM_SWITCH == 0
	then
		return
	end
	
	local ROLETAPREMIUM_ITENS_RANDOM = {}
	
	if ROLETAPREMIUM_PORCENTAGEM_SWITCH == 1
	then	
		for i in ipairs(ROLETAPREMIUM_ITENS) do
			qtd = (ROLETAPREMIUM_ITENS[i]._Porcentagem/100)*10000
			for x = 1, qtd do
				InsertKey(ROLETAPREMIUM_ITENS_RANDOM, ROLETAPREMIUM_ITENS[i])
			end			
		end
		for i in ipairs(ROLETAPREMIUM_COINS) do
			qtd = (ROLETAPREMIUM_COINS[i]._Porcentagem/100)*10000
			for x = 1, qtd do
				InsertKey(ROLETAPREMIUM_ITENS_RANDOM, ROLETAPREMIUM_COINS[i])
			end
		end
	else
		for i in ipairs(ROLETAPREMIUM_ITENS) do
			InsertKey(ROLETAPREMIUM_ITENS_RANDOM, ROLETAPREMIUM_ITENS[i])		
		end
		for i in ipairs(ROLETAPREMIUM_COINS) do
			InsertKey(ROLETAPREMIUM_ITENS_RANDOM, ROLETAPREMIUM_COINS[i])		
		end
	end
	
	if #ROLETAPREMIUM_ITENS_RANDOM > 0
	then
		return ROLETAPREMIUM_ITENS_RANDOM[GetRand(1, #ROLETAPREMIUM_ITENS_RANDOM)]
	end
	
	return -1
end

Commands.Register(ROLETAPREMIUM_COMMAND, RoletaPremium.Command)

return RoletaPremium