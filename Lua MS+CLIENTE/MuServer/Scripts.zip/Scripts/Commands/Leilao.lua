Leilao = {}

local leilaoStarted = false
local leilaoStartedCommand = false
local leilaoAreaStarted = false
local leilaoStaff = nil
local leilaoGanhador = {_nome = "Nenhum Lance Registrado", _lance = 0, _indexPlayer = 0}
local leilaoConfig = {}
local leilaoAnnounceMinutes = nil
local leilaoMinutos = nil
local leilaoSegundos = nil
local timerMinutos = nil
local timerSegundos = nil
local timerAnnounce = nil
local leilaoPremio = nil
local leilaoLanceMinimo = nil
local leilaoMoeda = nil
local leilaoArea = nil
local Player = {}


-- Variável global para contar os lances realizados
local leilaoLanceCount = 5

function Leilao.DarLance(playerIndex, Arguments)
    if not LEILAO_COMMAND_SWITCH and not LEILAO_SWITCH then
        return
    end
    
    local player = User.new(playerIndex)
    local Name = player:getName()
    local Account = player:getAccountID()
    local lance = command:getNumber(Arguments, 1)
    
    if leilaoStarted == true then
        if lance >= leilaoConfig._lanceMinimo then
            local saldo = DataBase.GetValue(leilaoConfig._tabela, leilaoConfig._coluna, leilaoConfig._where, Account)
            if saldo < lance then
                SendMessage(string.format("[Leilao] Você não tem saldo de %s suficiente.", leilaoConfig._nomeMoeda), playerIndex, 1)
                SendMessage(string.format("Seu saldo atual é de %d %s.", saldo, leilaoConfig._nomeMoeda), playerIndex, 1)
                return
            end
            
            leilaoConfig._lanceMinimo = lance + LEILAO_LANCE_VALOR_INCREMENTO
            leilaoGanhador = {_nome = Name, _lance = lance, _indexPlayer = playerIndex}
            
            leilaoLanceCount = leilaoLanceCount + 1 -- Incrementa o contador de lances
            
            -- Reduz o tempo com base no número de lances
            if leilaoLanceCount == 10 then
                leilaoSegundos = 30
                SendMessageGlobal("[Leilão] O tempo de finalização foi reduzido para 30 segundos!", 0)
            elseif leilaoLanceCount == 20 then
                leilaoSegundos = 15
                SendMessageGlobal("[Leilão] O tempo de finalização foi reduzido para 15 segundos!", 0)
            elseif leilaoLanceCount == 30 then
                leilaoSegundos = 5
                SendMessageGlobal("[Leilão] O tempo de finalização foi reduzido para 5 segundos!", 0)
            end
            
            SendMessage(string.format("[Leilao] Lance registrado."), playerIndex, 1)
            
            if LEILAO_LANCE_RETER_VALOR == 1 then
                DataBase.SetDecreaseValue(leilaoConfig._tabela, leilaoConfig._coluna, lance, leilaoConfig._where, Account)
                SendMessage(string.format("Foram descontados %d %s do seu saldo.", lance, leilaoConfig._nomeMoeda), playerIndex, 1)
            end
            
            -- Reinicia o timer com o novo tempo, se necessário
            if timerSegundos then
                Timer.Cancel(timerSegundos)
            end
            
            timerSegundos = Timer.Repeater(1, leilaoSegundos, Leilao.RunningSegundos)
            
            SendMessageGlobal(string.format("==== %s ====", leilaoConfig._nomeLeilao), 0)
            SendMessageGlobal(string.format("Utilize %s para mais informações", LEILAO_INFO_COMMAND), 0)
            SendMessageGlobal(string.format(" "), 0)
            SendMessageGlobal(string.format("Melhor Lance:"), 0)
            SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoConfig._nomeMoeda), 0)
            SendMessageGlobal(string.format("== Leilão finaliza em %d segundo(s) ==", leilaoSegundos), 0)
        else
            SendMessage(string.format("[Leilao] O lance deve ser maior ou igual ao mínimo: %d %s.", leilaoConfig._lanceMinimo, leilaoConfig._nomeMoeda), playerIndex, 1)
        end
    else
        SendMessage("[Leilao] Não há nenhum leilão em andamento.", playerIndex, 1)
    end
end

function Leilao.Init()
	
	if not LEILAO_SWITCH
	then
		return
	end
	
	Commands.Register(LEILAO_INFO_COMMAND, Leilao.Info)
	Commands.Register(LEILAO_BID_COMMAND, Leilao.DarLance)
	Commands.Register(LEILAO_REDEEM_COMMAND, Leilao.ResgatarPremio)
	Commands.Register(LEILAO_END_COMMAND, Leilao.ForceEnd)
	Commands.Register(LEILAO_START_COMMAND, Leilao.Command)
	Commands.Register(LEILAO_AREA_START_COMMAND, Leilao.Area)
	GameServerFunctions.PlayerMove(Leilao.CheckArea)
	
	for i in ipairs(LEILAO_AUTO_CRON) do
		if LEILAO_AUTO_CRON[i]._dayofweek ~= -1
		then
			Schedule.SetDayOfWeek(LEILAO_AUTO_CRON[i]._dayofweek, LEILAO_AUTO_CRON[i]._hour, LEILAO_AUTO_CRON[i]._minute, Leilao.Start, LEILAO_AUTO_CRON[i]._Index)
		elseif LEILAO_AUTO_CRON[i]._day ~= -1
		then
			Schedule.SetDayAndHourAndMinute(LEILAO_AUTO_CRON[i]._day, LEILAO_AUTO_CRON[i]._hour, LEILAO_AUTO_CRON[i]._minute, Leilao.Start, LEILAO_AUTO_CRON[i]._Index)
		else
			Schedule.SetHourAndMinute(LEILAO_AUTO_CRON[i]._hour, LEILAO_AUTO_CRON[i]._minute, Leilao.Start, LEILAO_AUTO_CRON[i]._Index)
		end
	end
end

function Leilao.Start(index)
	if not LEILAO_SWITCH
	then
		return
	end
	
	for i in ipairs(LEILAO_AUTO_CONFIG) do
		if LEILAO_AUTO_CONFIG[i]._Index == index
		then
			leilaoConfig = LEILAO_AUTO_CONFIG[i]
		end
	end
	
	leilaoAnnounceMinutes = LEILAO_ANNOUNCE
	
	SendMessageGlobal(string.format("==== EVENTO AUTOMATICO ===="), 0)
	SendMessageGlobal(string.format("%s inicia em %d minuto(s)", leilaoConfig._nomeLeilao, leilaoAnnounceMinutes), 0)
	timerAnnounce = Timer.Repeater(60, 	leilaoAnnounceMinutes, Leilao.Begin)

end

function Leilao.Command(staffIndex, Arguments)	
	if not LEILAO_COMMAND_SWITCH
	then
		return
	end
	
	local player = User.new(staffIndex)
	
	if player:getAuthority() == 1
	then
		return
	end
	
	if LEILAO_LOGIN_SWITCH == 1
	then
		local autorizado = false
		for i in ipairs(LEILAO_LOGIN_AUTORIZADO) do
			if player:getAccountID() == LEILAO_LOGIN_AUTORIZADO[i]._login and player:getName() == LEILAO_LOGIN_AUTORIZADO[i]._char
			then
				autorizado = true
				break
			end
		end
		if autorizado == false
		then
			return
		end
	end
	
	if leilaoStarted == false and leilaoStartedCommand == false and leilaoAreaStarted == false
	then
		local moeda = command:getString(Arguments, 1, 0)
		local lanceMinimo = command:getString(Arguments, 2, 0)
		leilaoPremio = command:getString(Arguments, 3, 1)
		
		leilaoPremio = string.sub(leilaoPremio, (string.len(moeda) + string.len(lanceMinimo) + 4))
		
		leilaoLanceMinimo = tonumber(lanceMinimo)
		
		local isMoeda = false
		
		for i in ipairs(LEILAO_LISTA_MOEDAS) do
			if LEILAO_LISTA_MOEDAS[i]._index == moeda
			then
				leilaoMoeda = LEILAO_LISTA_MOEDAS[i]
				isMoeda = true
				break
			end
		end
		
		if isMoeda == false
		then
			SendMessage(string.format("[Leilao] Index da moeda inexistente."), staffIndex, 1)
			return
		end
		
		if leilaoLanceMinimo == nil or leilaoLanceMinimo < 0
		then
			SendMessage(string.format("[Leilao] lance minimo invalido."), staffIndex, 1)
			return
		end
		
		if leilaoPremio == nil
		then
		    SendMessage(string.format("[Leilao] Item leilado invalido."), staffIndex, 1)
			return
		end
		
		leilaoStaff = staffIndex
		leilaoStartedCommand = true
		leilaoMinutos = LEILAO_TEMPO_MINUTOS
		leilaoSegundos = LEILAO_TEMPO_SEGUNDOS	
		
		SendMessageGlobal(string.format("========= LEILAO ========="), 0)
		SendMessageGlobal(string.format("Utilize %s [valor] para dar um lance", LEILAO_BID_COMMAND), 0)
		SendMessageGlobal(string.format(" "), 0)
		SendMessageGlobal(string.format("Item: %s", leilaoPremio), 0)
		SendMessageGlobal(string.format("Lance Inicial: %d %s", leilaoLanceMinimo, leilaoMoeda._nome), 0)
		SendMessageGlobal(string.format("== Leilao finaliza em %d minuto(s) ==", leilaoMinutos), 0)

		timerMinutos = Timer.Repeater(60, 	leilaoMinutos, Leilao.RunningMinutos)
	else
		SendMessage(string.format("[Leilao] Finalize o Leilao atual antes de iniciar outro."), staffIndex, 1)
		return
	end
end	

function Leilao.Area(staffIndex, Arguments)
	if not LEILAO_COMMAND_SWITCH
	then
		return
	end
	
	local player = User.new(staffIndex)
	
	if player:getAuthority() == 1
	then
		return
	end
	
	if LEILAO_LOGIN_SWITCH == 1
	then
		local autorizado = false
		for i in ipairs(LEILAO_LOGIN_AUTORIZADO) do
			if player:getAccountID() == LEILAO_LOGIN_AUTORIZADO[i]._login and player:getName() == LEILAO_LOGIN_AUTORIZADO[i]._char
			then
				autorizado = true
				break
			end
		end
		if autorizado == false
		then
			return
		end
	end
	
	if leilaoStarted == false and leilaoStartedCommand == false and leilaoAreaStarted == false
	then
		local area = command:getString(Arguments, 1, 0)
		local moeda = command:getString(Arguments, 2, 0)
		local lanceMinimo = command:getString(Arguments, 3, 0)
		leilaoPremio = command:getString(Arguments, 3, 1)
		
		leilaoPremio = string.sub(leilaoPremio, (string.len(area) + string.len(moeda) + string.len(lanceMinimo) + 4))
		
		leilaoLanceMinimo = tonumber(lanceMinimo)
		
		if leilaoLanceMinimo == nil or leilaoLanceMinimo < 0
		then
			SendMessage(string.format("[Leilao] lance minimo invalido."), staffIndex, 1)
			return
		end
		
		local isMoeda = false
		
		for i in ipairs(LEILAO_LISTA_MOEDAS) do
			if LEILAO_LISTA_MOEDAS[i]._index == moeda
			then
				leilaoMoeda = LEILAO_LISTA_MOEDAS[i]
				isMoeda = true
				break
			end
		end
		
		if isMoeda == false
		then
			SendMessage(string.format("[Leilao] Index da moeda inexistente."), staffIndex, 1)
			return
		end
		
		local isArea = false
		for i in ipairs(LEILAO_AREA) do
			if LEILAO_AREA[i]._index == area
			then
				leilaoArea = LEILAO_AREA[i]
				isArea = true
				break
			end
		end
		
		if isArea == false
		then
			SendMessage(string.format("[Leilao] Index da area inexistente."), staffIndex, 1)
			return
		end
		
		leilaoStaff = staffIndex
		leilaoAreaStarted = true
		leilaoMinutos = LEILAO_TEMPO_MINUTOS
		leilaoSegundos = LEILAO_TEMPO_SEGUNDOS	
		
		SendMessageGlobal(string.format("========= LEILAO ========="), 0)
		SendMessageGlobal(string.format("Utilize %s [valor] para dar um lance", LEILAO_BID_COMMAND), 0)
		SendMessageGlobal(string.format(" "), 0)
		SendMessageGlobal(string.format("Item: %s", leilaoPremio), 0)
		SendMessageGlobal(string.format("Lance Inicial: %d %s", leilaoLanceMinimo, leilaoMoeda._nome), 0)
		SendMessageGlobal(string.format("== Leilao finaliza em %d minuto(s) ==", leilaoMinutos), 0)

		timerMinutos = Timer.Repeater(60, 	leilaoMinutos, Leilao.RunningMinutos)
	else
		SendMessage(string.format("[Leilao] Finalize o Leilao atual antes de iniciar outro."), staffIndex, 1)
		return
	end
end

function Leilao.Begin()	
	if not LEILAO_SWITCH
	then
		return
	end
	
	leilaoAnnounceMinutes = leilaoAnnounceMinutes -1
	
	if leilaoAnnounceMinutes > 0
	then
		SendMessageGlobal(string.format("==== EVENTO AUTOMATICO ===="), 0)
		SendMessageGlobal(string.format("%s inicia em %d minuto(s)", leilaoConfig._nomeLeilao, leilaoAnnounceMinutes), 0)
	else
		Timer.Cancel(timerAnnounce)
		timerAnnounce = nil
				
		leilaoStarted = true
		leilaoMinutos = LEILAO_TEMPO_MINUTOS
		leilaoSegundos = LEILAO_TEMPO_SEGUNDOS	
		
		SendMessageGlobal(string.format("==== %s ====", leilaoConfig._nomeLeilao), 0)
		SendMessageGlobal(string.format("Utilize %s <valor> para dar um lance", LEILAO_BID_COMMAND), 0)
		SendMessageGlobal(string.format(" "), 0)
		SendMessageGlobal(string.format("Lance Inicial: %d %s", leilaoConfig._lanceMinimo, leilaoConfig._nomeMoeda), 0)
		SendMessageGlobal(string.format(" "), 0)
		SendMessageGlobal(string.format("== Leilao finaliza em %d minuto(s) ==", leilaoMinutos), 0)
	
		timerMinutos = Timer.Repeater(60, 	leilaoMinutos, Leilao.RunningMinutos)
	end
end	

function Leilao.RunningMinutos()
	leilaoMinutos = leilaoMinutos - 1
	
	if leilaoStarted == true
	then
		if leilaoMinutos > 0
		then		
			SendMessageGlobal(string.format("==== %s ====", leilaoConfig._nomeLeilao), 0)
			SendMessageGlobal(string.format("Utilize %s para mais informacoes", LEILAO_INFO_COMMAND), 0)
			SendMessageGlobal(string.format(" "), 0)
			SendMessageGlobal(string.format("Melhor Lance:"), 0)
			SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoConfig._nomeMoeda), 0)
			SendMessageGlobal(string.format("== Leilao finaliza em %d minuto(s) ==", leilaoMinutos), 0)
		else
			Timer.Cancel(timerMinutos)
			timerMinutos = nil
			SendMessageGlobal(string.format("==== %s ====", leilaoConfig._nomeLeilao), 0)
			SendMessageGlobal(string.format("Utilize %s para mais informacoes", LEILAO_INFO_COMMAND), 0)
			SendMessageGlobal(string.format(" "), 0)
			SendMessageGlobal(string.format("Melhor Lance:"), 0)
			SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoConfig._nomeMoeda), 0)
			SendMessageGlobal(string.format("== Leilao finaliza em %d segundo(s) ==", leilaoSegundos), 0)
			timerSegundos = Timer.Repeater(1, leilaoSegundos, Leilao.RunningSegundos)
		end
	elseif leilaoStartedCommand == true or leilaoAreaStarted == true
	then
		if leilaoMinutos > 0
		then		
			SendMessageGlobal(string.format("========= LEILAO ========="), 0)
			SendMessageGlobal(string.format("Utilize %s para mais informa��es", LEILAO_INFO_COMMAND), 0)
			SendMessageGlobal(string.format(" "), 0)
			SendMessageGlobal(string.format("Melhor Lance:"), 0)
			SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoMoeda._nome), 0)
			SendMessageGlobal(string.format("== Leilao finaliza em %d minuto(s) ==", leilaoMinutos), 0)
		else
			Timer.Cancel(timerMinutos)
			timerMinutos = nil
			SendMessageGlobal(string.format("========= LEILAO ========="), 0)
			SendMessageGlobal(string.format("Utilize %s para mais informacoes", LEILAO_INFO_COMMAND), 0)
			SendMessageGlobal(string.format(" "), 0)
			SendMessageGlobal(string.format("Melhor Lance:"), 0)
			SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoMoeda._nome), 0)
			SendMessageGlobal(string.format("== Leilao finaliza em %d segundo(s) ==", leilaoSegundos), 0)
			timerSegundos = Timer.Repeater(1, leilaoSegundos, Leilao.RunningSegundos)
		end
	end
end

function Leilao.RunningSegundos()
	leilaoSegundos = leilaoSegundos - 1
	
	if leilaoStarted == true
	then	
		if leilaoSegundos > 0
		then
			SendMessageGlobal(string.format("==== %s ====", leilaoConfig._nomeLeilao), 0)
			SendMessageGlobal(string.format("Utilize %s para mais informacoes", LEILAO_INFO_COMMAND), 0)
			SendMessageGlobal(string.format(" "), 0)
			SendMessageGlobal(string.format("Melhor Lance:"), 0)
			SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoConfig._nomeMoeda), 0)
			SendMessageGlobal(string.format("== Leilao finaliza em %d segundo(s) ==", leilaoSegundos), 0)
		else
			Timer.Cancel(timerSegundos)
			timerSegundos = nil
			Leilao.End()
		end	
	elseif leilaoStartedCommand == true  or leilaoAreaStarted == true
	then
		if leilaoSegundos > 0
		then
			SendMessageGlobal(string.format("========= LEILAO ========="), 0)
			SendMessageGlobal(string.format("Utilize %s para mais informacoes", LEILAO_INFO_COMMAND), 0)
			SendMessageGlobal(string.format(" "), 0)
			SendMessageGlobal(string.format("Melhor Lance:"), 0)
			SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoMoeda._nome), 0)
			SendMessageGlobal(string.format("== Leilao finaliza em %d segundo(s) ==", leilaoSegundos), 0)
		else
			Timer.Cancel(timerSegundos)
			timerSegundos = nil
			Leilao.End()
		end	
	end
end

function Leilao.DarLance(playerIndex, Arguments)
	if not LEILAO_COMMAND_SWITCH and not LEILAO_SWITCH
	then
		return
	end
	
	local player = User.new(playerIndex)
	
	local Name = player:getName()
	local Account = player:getAccountID()
	
	local lance = command:getNumber(Arguments, 1)
	
	if leilaoStarted == true
	then			
		if lance >= leilaoConfig._lanceMinimo
		then
			local saldo = DataBase.GetValue(leilaoConfig._tabela, leilaoConfig._coluna , leilaoConfig._where, Account)
			if  saldo < lance
			then
				SendMessage(string.format("[Leilao] voce nao tem saldo de %s suficiente.", leilaoConfig._nomeMoeda), playerIndex, 1)
				SendMessage(string.format("Seu saldo atual e de %d %s.", saldo, leilaoConfig._nomeMoeda), playerIndex, 1)
				return
			end	
			
			leilaoConfig._lanceMinimo = lance + LEILAO_LANCE_VALOR_INCREMENTO
			leilaoGanhador = {_nome = Name, _lance = lance, _indexPlayer = playerIndex}
			
			SendMessage(string.format("[Leilao] Lance registrado."), playerIndex, 1)
			
			if LEILAO_LANCE_RETER_VALOR == 1
			then
				DataBase.SetDecreaseValue(leilaoConfig._tabela, leilaoConfig._coluna, lance, leilaoConfig._where, Account)
				SendMessage(string.format("Foram descontados %d %s do seu saldo.", lance, leilaoConfig._nomeMoeda), playerIndex, 1)
			end
					
			if leilaoMinutos > 0
			then				
				SendMessageGlobal(string.format("==== %s ====", leilaoConfig._nomeLeilao), 0)
				SendMessageGlobal(string.format("Utilize %s para mais informacoes", LEILAO_INFO_COMMAND), 0)
				SendMessageGlobal(string.format(" "), 0)
				SendMessageGlobal(string.format("Melhor Lance:"), 0)
				SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoConfig._nomeMoeda), 0)
				SendMessageGlobal(string.format("== Leilao finaliza em %d minuto(s) ==", leilaoMinutos), 0)
			else
				if LEILAO_LANCE_TIMER_SWITCH == 1
				then
					Timer.Cancel(timerSegundos)
					timerSegundos = nil
					leilaoSegundos = LEILAO_LANCE_TIMER_TEMPO
					
					SendMessageGlobal(string.format("==== %s ====", leilaoConfig._nomeLeilao), 0)
					SendMessageGlobal(string.format("Utilize %s para mais informacoes", LEILAO_INFO_COMMAND), 0)
					SendMessageGlobal(string.format(" "), 0)
					SendMessageGlobal(string.format("Melhor Lance:"), 0)
					SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoConfig._nomeMoeda), 0)
					SendMessageGlobal(string.format("== Leilao finaliza em %d segundo(s) ==", leilaoSegundos), 0)
					
					timerSegundos = Timer.Repeater(1, leilaoSegundos, Leilao.RunningSegundos)
				else
					SendMessageGlobal(string.format("==== %s ====", leilaoConfig._nomeLeilao), 0)
					SendMessageGlobal(string.format("Utilize %s para mais informacoes", LEILAO_INFO_COMMAND), 0)
					SendMessageGlobal(string.format(" "), 0)
					SendMessageGlobal(string.format("Melhor Lance:"), 0)
					SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoConfig._nomeMoeda), 0)
					SendMessageGlobal(string.format("== Leilao finaliza em %d segundo(s) ==", leilaoSegundos), 0)
				end			
			end		
		elseif lance < leilaoConfig._lanceMinimo
		then
			SendMessage(string.format("[Leilao] Lance minimo: %s %s.", leilaoConfig._lanceMinimo, leilaoConfig._nomeMoeda), playerIndex, 1)
		else
			SendMessage(string.format("[Leilao] Lance Invalido."), playerIndex, 1)
		end
	elseif leilaoStartedCommand == true
	then
		if leilaoLanceMinimo == nil or leilaoLanceMinimo < 0
		then
			return
		end
		
		if lance >= leilaoLanceMinimo
		then
			local saldo = DataBase.GetValue(leilaoMoeda._tabela, leilaoMoeda._coluna , leilaoMoeda._where, Account)
			if  saldo < lance
			then
				SendMessage(string.format("[Leilao] Voce nao tem saldo de %s suficiente.", leilaoMoeda._nome), playerIndex, 1)
				SendMessage(string.format("Seu saldo atual e de %d %s.", saldo, leilaoMoeda._nome), playerIndex, 1)
				return
			end	
			
			leilaoLanceMinimo = lance + LEILAO_LANCE_VALOR_INCREMENTO
			leilaoGanhador = {_nome = Name, _lance = lance, _indexPlayer = playerIndex}
			
			SendMessage(string.format("[Leilao] Lance registrado."), playerIndex, 1)
			
			if LEILAO_LANCE_RETER_VALOR == 1
			then
				DataBase.SetDecreaseValue(leilaoMoeda._tabela, leilaoMoeda._coluna, lance, leilaoMoeda._where, Account)
				SendMessage(string.format("Foram descontados %d %s do seu saldo.", lance, leilaoMoeda._nome), playerIndex, 1)
			end
					
			if leilaoMinutos > 0
			then				
				SendMessageGlobal(string.format("========= LEILAO ========="), 0)
				SendMessageGlobal(string.format("Utilize %s para mais informacoes", LEILAO_INFO_COMMAND), 0)
				SendMessageGlobal(string.format(" "), 0)
				SendMessageGlobal(string.format("Melhor Lance:"), 0)
				SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoMoeda._nome), 0)
				SendMessageGlobal(string.format("== Leilao finaliza em %d minuto(s) ==", leilaoMinutos), 0)
			else
				if LEILAO_LANCE_TIMER_SWITCH == 1
				then
					Timer.Cancel(timerSegundos)
					timerSegundos = nil
					leilaoSegundos = LEILAO_LANCE_TIMER_TEMPO
					
					SendMessageGlobal(string.format("========= LEIL\195O ========="), 0)
					SendMessageGlobal(string.format("Utilize %s para mais informacoes", LEILAO_INFO_COMMAND), 0)
					SendMessageGlobal(string.format(" "), 0)
					SendMessageGlobal(string.format("Melhor Lance:"), 0)
					SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoMoeda._nome), 0)
					SendMessageGlobal(string.format("== Leilao finaliza em %d segundo(s) ==", leilaoSegundos), 0)
					
					timerSegundos = Timer.Repeater(1, leilaoSegundos, Leilao.RunningSegundos)
				else
					SendMessageGlobal(string.format("========= LEILAO ========="), 0)
					SendMessageGlobal(string.format("Utilize %s para mais informa\231\245es", LEILAO_INFO_COMMAND), 0)
					SendMessageGlobal(string.format(" "), 0)
					SendMessageGlobal(string.format("Melhor Lance:"), 0)
					SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoMoeda._nome), 0)
					SendMessageGlobal(string.format("== Leilao finaliza em %d segundo(s) ==", leilaoSegundos), 0)
				end			
			end
		
		elseif lance < leilaoLanceMinimo
		then
			SendMessage(string.format("[Leilao] Lance minimo: %s %s.", leilaoLanceMinimo, leilaoMoeda._nome), playerIndex, 1)
		else
			SendMessage(string.format("[Leilao] Lance Invalido."), playerIndex, 1)
		end
	elseif leilaoAreaStarted == true
	then
		if leilaoLanceMinimo == nil or leilaoLanceMinimo < 0
		then
			return
		end
		
		if player:getMapNumber() == leilaoArea._map and player:getX() >= leilaoArea._x1 and player:getX() <= leilaoArea._x2 and player:getY() >= leilaoArea._y1 and player:getY() <= leilaoArea._y2
		then
		
			if lance >= leilaoLanceMinimo
			then
				local saldo = DataBase.GetValue(leilaoMoeda._tabela, leilaoMoeda._coluna , leilaoMoeda._where, Account)
				if  saldo < lance
				then
					SendMessage(string.format("[Leilao] Voce nao tem saldo de %s suficiente.", leilaoMoeda._nome), playerIndex, 1)
					SendMessage(string.format("Seu saldo atual e de %d %s.", saldo, leilaoMoeda._nome), playerIndex, 1)
					return
				end	
				
				leilaoLanceMinimo = lance + LEILAO_LANCE_VALOR_INCREMENTO
				leilaoGanhador = {_nome = Name, _lance = lance, _indexPlayer = playerIndex}
				
				SendMessage(string.format("[Leilao] Lance registrado."), playerIndex, 1)
				
				if LEILAO_LANCE_RETER_VALOR == 1
				then
					DataBase.SetDecreaseValue(leilaoMoeda._tabela, leilaoMoeda._coluna, lance, leilaoMoeda._where, Account)
					SendMessage(string.format("Foram descontados %d %s do seu saldo.", lance, leilaoMoeda._nome), playerIndex, 1)
				end
						
				if leilaoMinutos > 0
				then				
					SendMessageGlobal(string.format("========= LEILAO ========="), 0)
					SendMessageGlobal(string.format("Utilize %s para mais informacoes", LEILAO_INFO_COMMAND), 0)
					SendMessageGlobal(string.format(" "), 0)
					SendMessageGlobal(string.format("Melhor Lance:"), 0)
					SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoMoeda._nome), 0)
					SendMessageGlobal(string.format("== Leilao finaliza em %d minuto(s) ==", leilaoMinutos), 0)
				else
					if LEILAO_LANCE_TIMER_SWITCH == 1
					then
						Timer.Cancel(timerSegundos)
						timerSegundos = nil
						leilaoSegundos = LEILAO_LANCE_TIMER_TEMPO
						
						SendMessageGlobal(string.format("========= LEILAO ========="), 0)
						SendMessageGlobal(string.format("Utilize %s para mais informacoes", LEILAO_INFO_COMMAND), 0)
						SendMessageGlobal(string.format(" "), 0)
						SendMessageGlobal(string.format("Melhor Lance:"), 0)
						SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoMoeda._nome), 0)
						SendMessageGlobal(string.format("== Leilao finaliza em %d segundo(s) ==", leilaoSegundos), 0)
						
						timerSegundos = Timer.Repeater(1, leilaoSegundos, Leilao.RunningSegundos)
					else
						SendMessageGlobal(string.format("========= LEILAO ========="), 0)
						SendMessageGlobal(string.format("Utilize %s para mais informacoes", LEILAO_INFO_COMMAND), 0)
						SendMessageGlobal(string.format(" "), 0)
						SendMessageGlobal(string.format("Melhor Lance:"), 0)
						SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoMoeda._nome), 0)
						SendMessageGlobal(string.format("== Leilao finaliza em %d segundo(s) ==", leilaoSegundos), 0)
					end			
				end
			
			elseif lance < leilaoLanceMinimo
			then
				SendMessage(string.format("[Leilao] Lance minimo: %s %s.", leilaoLanceMinimo, leilaoMoeda._nome), playerIndex, 1)
			else
				SendMessage(string.format("[Leilao] Lance Invalido."), playerIndex, 1)
			end
		else
			SendMessage(string.format("[Sistema] voce precisa estar dentro da area do leilao para poder dar lances."), playerIndex, 1)
			return
		end
	else
		SendMessage(string.format("[Sistema] nao ha Leilao em andamento."), playerIndex, 1)
		return
	end		
end

function Leilao.End()
	local player = User.new(leilaoGanhador._indexPlayer)
	if leilaoStarted == true
	then
		leilaoStarted = false
		
		if leilaoGanhador._lance == 0
		then
			SendMessageGlobal(string.format("==== %s ====", leilaoConfig._nomeLeilao), 0)
			SendMessageGlobal(string.format(" "), 0)
			SendMessageGlobal(string.format("SEM VENCEDOR"), 0)
			SendMessageGlobal(string.format("Nenhum lance registrado.", leilaoGanhador._nome, leilaoGanhador._lance, leilaoConfig._nomeMoeda), 0)
			SendMessageGlobal(string.format(" "), 0)
			SendMessageGlobal(string.format("== Agradecemos a atençao de todos =="), 0)
			
			Leilao.Clear()
			return
		end
		
		SendMessageGlobal(string.format("==== %s ====", leilaoConfig._nomeLeilao), 0)
		SendMessageGlobal(string.format(" "), 0)
		SendMessageGlobal(string.format("LANCE VENCEDOR:"), 0)
		SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoConfig._nomeMoeda), 0)
		SendMessageGlobal(string.format(" "), 0)
		SendMessageGlobal(string.format("== Agradecemos a participaçao de todos =="), 0)
		
		if LEILAO_LANCE_RETER_VALOR == 0
		then					
			DataBase.SetDecreaseValue(leilaoConfig._tabela, leilaoConfig._coluna, leilaoGanhador._lance, leilaoConfig._where, player:getAccountID())
			SendMessage(string.format("[Leilao] Parabens, voce venceu!"), leilaoGanhador._indexPlayer, 1)
			SendMessage(string.format("Foram descontados %d %s do seu saldo.", leilaoGanhador._lance, leilaoConfig._nomeMoeda), leilaoGanhador._indexPlayer, 1)
		end
		local nomeArquivo = Leilao.GerarNome(30)
		
		local file = io.open(string.format("..\\Data\\Scripts\\PremiosLeilao\\%s.txt",nomeArquivo), "a+")
		
		for i in ipairs(LEILAO_AUTO_CONFIG_ITENS) do	
			local item = LEILAO_AUTO_CONFIG_ITENS[i]		
			if item._Index == leilaoConfig._Index
			then
				local exc = 0		
				
				if item._Exc_1 ~= 0
				then
					exc = exc + 1
				end
				if item._Exc_2 ~= 0
				then
					exc = exc + 2
				end
				if item._Exc_3 ~= 0
				then
					exc = exc + 4
				end
				if item._Exc_4 ~= 0
				then
					exc = exc + 8
				end
				if item._Exc_5 ~= 0
				then
					exc = exc + 16
				end
				if item._Exc_6 ~= 0
				then
					exc = exc + 32
				end
						
				file:write(string.format("_ItemSection=%d;_ItemIndex=%d;_Level=%d;_Durabilidade=%d;_Luck=%d;_Skill=%d;_Opt=%d;_Exc=%d;_Count=%d",item._ItemSection,item._ItemIndex,item._Level,item._Durabilidade,item._Luck,item._Skill,item._Opt,exc,item._Count), "\n")
			end
		end
		file:close()
		
		SendMessage(string.format("[Leilao] Use %s",LEILAO_REDEEM_COMMAND ), leilaoGanhador._indexPlayer, 1)
		SendMessage(string.format("para resgatar seu premio.",LEILAO_REDEEM_COMMAND ), leilaoGanhador._indexPlayer, 1)
		
		DataBase.SetValue("Character", "LeilaoPremioRetirado", 1, "Name", leilaoGanhador._nome)
		DataBase.SetString("Character", "LeilaoPremioCodigo", nomeArquivo, "Name", leilaoGanhador._nome)
		
		Leilao.Clear()
		return
	elseif leilaoStartedCommand == true or leilaoAreaStarted == true
	then
		leilaoStartedCommand = false
		leilaoAreaStarted = false
	
		if leilaoGanhador._lance == 0
		then
			SendMessageGlobal(string.format("==== LEILAO ===="), 0)
			SendMessageGlobal(string.format(" "), 0)
			SendMessageGlobal(string.format("SEM VENCEDOR"), 0)
			SendMessageGlobal(string.format("Nenhum lance registrado.", leilaoGanhador._nome, leilaoGanhador._lance, leilaoConfig._nomeMoeda), 0)
			SendMessageGlobal(string.format(" "), 0)
			SendMessageGlobal(string.format("== Agradecemos a atençao de todos =="), 0)
			
			Leilao.Clear()
			return
		end
		
		SendMessageGlobal(string.format("========= LEILAO ========="), 0)
		SendMessageGlobal(string.format("LANCE VENCEDOR:"), 0)
		SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoMoeda._nome), 0)
		SendMessageGlobal(string.format("Premio: %s", leilaoPremio), 0)
		SendMessageGlobal(string.format(" "), 0)
		SendMessageGlobal(string.format("== Agradecemos a participaçao de todos =="), 0)
		
		if LEILAO_LANCE_RETER_VALOR == 0
		then
			DataBase.SetDecreaseValue(leilaoMoeda._tabela, leilaoMoeda._coluna, leilaoGanhador._lance, leilaoMoeda._where, player:getAccountID())
			SendMessage(string.format("[Leilao] Parabens, voce venceu!"), leilaoGanhador._indexPlayer, 1)
			SendMessage(string.format("Foram descontados %d %s do seu saldo.", leilaoGanhador._lance, leilaoMoeda._nome), leilaoGanhador._indexPlayer, 1)
		end
		
		local player = User.new(leilaoStaff)
		
		local map = player:getMapNumber()
		local x = player:getX()
		local y = player:getY()		
		
		Teleport(leilaoGanhador._indexPlayer, map, x, y)
		
		Leilao.Clear()
		return
	end
end

function Leilao.ForceEnd(staffIndex, Arguments)
	if not LEILAO_COMMAND_SWITCH
	then
		return
	end
	
    if player:getAuthority() ~= 32
    then
        return
    end
	
	if LEILAO_LOGIN_SWITCH == 1
	then
		local autorizado = false
		for i in ipairs(LEILAO_LOGIN_AUTORIZADO) do
			if player:getAccountID(staffIndex) == LEILAO_LOGIN_AUTORIZADO[i]._login and player:getName(staffIndex) == LEILAO_LOGIN_AUTORIZADO[i]._char
			then
				autorizado = true
				
			end
		end
		if autorizado == false
		then
			return
		end
	end
	
	if leilaoStarted == false and leilaoStartedCommand == false and leilaoAreaStarted == false
	then
		SendMessage(string.format("[Sistema] Nenhum Leilao em andamento"), staffIndex, 1)
	end
	
	if timerMinutos ~= nil
	then
		Timer.Cancel(timerMinutos)
		timerMinutos = nil
	end
	
	if timerSegundos ~= nil
	then
		Timer.Cancel(timerSegundos)
		timerSegundos = nil
	end
	
	if leilaoStarted == true
	then
		leilaoStarted = false
		
		if leilaoGanhador._lance == 0
		then
			SendMessageGlobal(string.format("==== %s ====", leilaoConfig._nomeLeilao), 0)
			SendMessageGlobal(string.format(" "), 0)
			SendMessageGlobal(string.format("SEM VENCEDOR"), 0)
			SendMessageGlobal(string.format("Nenhum lance registrado.", leilaoGanhador._nome, leilaoGanhador._lance, leilaoConfig._nomeMoeda), 0)
			SendMessageGlobal(string.format(" "), 0)
			SendMessageGlobal(string.format("== Agradecemos a atençao de todos =="), 0)
			
			Leilao.Clear()
			return
		end
		
		SendMessageGlobal(string.format("==== %s ====", leilaoConfig._nomeLeilao), 0)
		SendMessageGlobal(string.format(" "), 0)
		SendMessageGlobal(string.format("LANCE VENCEDOR:"), 0)
		SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoConfig._nomeMoeda), 0)
		SendMessageGlobal(string.format(" "), 0)
		SendMessageGlobal(string.format("== Agradecemos a participaçao de todos =="), 0)
		
		if LEILAO_LANCE_RETER_VALOR == 0
		then					
			DataBase.SetDecreaseValue(leilaoConfig._tabela, leilaoConfig._coluna, leilaoGanhador._lance, leilaoConfig._where, player:getAccountID(leilaoGanhador._indexPlayer))
			SendMessage(string.format("[Leilao] Parabens, voce venceu!"), leilaoGanhador._indexPlayer, 1)
			SendMessage(string.format("Foram descontados %d %s do seu saldo.", leilaoGanhador._lance, leilaoConfig._nomeMoeda), leilaoGanhador._indexPlayer, 1)
		end
		local nomeArquivo = Leilao.GerarNome(30)
		
		local file = io.open(string.format("..\\Data\\Scripts\\PremiosLeilao\\%s.txt",nomeArquivo), "a+")
		
		for i in ipairs(LEILAO_AUTO_CONFIG_ITENS) do	
			local item = LEILAO_AUTO_CONFIG_ITENS[i]		
			if item._Index == leilaoConfig._Index
			then
				local exc = 0		
				
				if item._Exc_1 ~= 0
				then
					exc = exc + 1
				end
				if item._Exc_2 ~= 0
				then
					exc = exc + 2
				end
				if item._Exc_3 ~= 0
				then
					exc = exc + 4
				end
				if item._Exc_4 ~= 0
				then
					exc = exc + 8
				end
				if item._Exc_5 ~= 0
				then
					exc = exc + 16
				end
				if item._Exc_6 ~= 0
				then
					exc = exc + 32
				end
						
				file:write(string.format("_ItemSection=%d;_ItemIndex=%d;_Level=%d;_Durabilidade=%d;_Luck=%d;_Skill=%d;_Opt=%d;_Exc=%d;_Count=%d",item._ItemSection,item._ItemIndex,item._Level,item._Durabilidade,item._Luck,item._Skill,item._Opt,exc,item._Count), "\n")
			end
		end
		file:close()
		
		SendMessage(string.format("[Leilao] Use %s",LEILAO_REDEEM_COMMAND ), leilaoGanhador._indexPlayer, 1)
		SendMessage(string.format("para resgatar seu premio.",LEILAO_REDEEM_COMMAND ), leilaoGanhador._indexPlayer, 1)
		
		DataBase.SetValue("Character", "LeilaoPremioRetirado", 1, "Name", leilaoGanhador._nome)
		DataBase.SetString("Character", "LeilaoPremioCodigo", nomeArquivo, "Name", leilaoGanhador._nome)
		
		Leilao.Clear()
		return
	elseif leilaoStartedCommand == true or leilaoAreaStarted == true
	then
		leilaoStartedCommand = false
		leilaoAreaStarted = false
		
		if leilaoGanhador._lance == 0
		then
			SendMessageGlobal(string.format("==== LEILAO ===="), 0)
			SendMessageGlobal(string.format(" "), 0)
			SendMessageGlobal(string.format("SEM VENCEDOR"), 0)
			SendMessageGlobal(string.format("Nenhum lance registrado.", leilaoGanhador._nome, leilaoGanhador._lance, leilaoConfig._nomeMoeda), 0)
			SendMessageGlobal(string.format(" "), 0)
			SendMessageGlobal(string.format("== Agradecemos a atençao de todos =="), 0)
			
			Leilao.Clear()
			return
		end
		
		SendMessageGlobal(string.format("========= LEILAO ========="), 0)
		SendMessageGlobal(string.format("LANCE VENCEDOR:"), 0)
		SendMessageGlobal(string.format("%s: %d %s", leilaoGanhador._nome, leilaoGanhador._lance, leilaoMoeda._nome), 0)
		SendMessageGlobal(string.format("Premio: %s", leilaoPremio), 0)
		SendMessageGlobal(string.format(" "), 0)
		SendMessageGlobal(string.format("== Agradecemos a participaçao de todos =="), 0)
		
		if LEILAO_LANCE_RETER_VALOR == 0
		then					
			DataBase.SetDecreaseValue(leilaoMoeda._tabela, leilaoMoeda._coluna, leilaoGanhador._lance, leilaoMoeda._where, player:getAccountID(leilaoGanhador._indexPlayer))
			SendMessage(string.format("[Leilao] Parabens, voce venceu!"), leilaoGanhador._indexPlayer, 1)
			SendMessage(string.format("Foram descontados %d %s do seu saldo.", leilaoGanhador._lance, leilaoMoeda._nome), leilaoGanhador._indexPlayer, 1)
		end
		
		local player = User.new(leilaoStaff)
		
		local map = player:getMapNumber()
		local x = player:getX()
		local y = player:getY()		
		
		Teleport(leilaoGanhador._indexPlayer, map, x, y)
		
		Leilao.Clear()
		return
	end	
end

function Leilao.Info(aIndex, Arguments)
	if not LEILAO_COMMAND_SWITCH and not LEILAO_SWITCH
	then
		return
	end
	
	if leilaoStarted == false and leilaoStartedCommand == false and leilaoAreaStarted == false
	then
		SendMessage(string.format("[Sistema] nao ha Leilao em andamento."), aIndex, 1)
		SendMessage(string.format("[Sistema] Use %s", LEILAO_REDEEM_COMMAND ), aIndex, 1)
		SendMessage(string.format("para resgatar premios pendentes.",LEILAO_REDEEM_COMMAND ), aIndex, 1)
		return
	end
	
	if leilaoStarted == true
	then
		SendMessage(string.format("[Leilao] %s", leilaoConfig._nomeLeilao), aIndex, 1)
		SendMessage(string.format("[Leilao] Lance minimo: %s %s.", leilaoConfig._lanceMinimo, leilaoConfig._nomeMoeda), aIndex, 1)
		SendMessage(string.format("[Leilao] Use %s [valor] para dar um lance.", LEILAO_BID_COMMAND), aIndex, 1)
	elseif leilaoStartedCommand == true or leilaoAreaStarted == true
	then
	
		SendMessage(string.format("[Leilao] Premio: %s", leilaoPremio), aIndex, 1)
		SendMessage(string.format("[Leilao] Lance minimo: %d %s.", leilaoLanceMinimo, leilaoMoeda._nome), aIndex, 1)
		SendMessage(string.format("[Leilao] Use %s <valor> para dar um lance.", LEILAO_BID_COMMAND), aIndex, 1)
	end	
end

function Leilao.ResgatarPremio(aIndex, Arguments)
	if not LEILAO_SWITCH
	then
		return
	end
	
	local player = User.new(aIndex)
	local pInv = Inventory.new(aIndex)
	
	local Name = player:getName()
	
	if DataBase.GetValue("Character", "LeilaoPremioRetirado", "Name", Name) == 0
	then
		SendMessage(string.format("[Sistema] voce nao tem premios a serem resgatados."), aIndex, 1)
		return
	end
	
	for i = 12, 75 do
			if pInv:isItem(i) ~= 0 then
				SendMessage(string.format("[Sistema] Seu inventario precisa estar vazio!"), aIndex, 1)
			return
		end
	end
	
	local ITENS = {}
	local fileName = DataBase.GetString("Character", "LeilaoPremioCodigo", "Name", Name)
	
	local file = io.open(string.format("..\\Data\\Scripts\\PremiosLeilao\\%s.txt", fileName), "r+")

	for line in file:lines() do
		local item = Leilao.ConverterString(line)
		InsertKey(ITENS, item)
	end
		
	file:close()
		
	for i in ipairs(ITENS) do
		local Item = ITENS[i]
		for forcount = 1, Item._Count do
			ItemSerialCreate(aIndex, 236, 0, 0, GET_ITEM(Item._ItemSection, Item._ItemIndex), Item._Level, Item._Durabilidade, Item._Luck, Item._Skill, Item._Opt, Item._Exc)
		end
	end
	os.remove(string.format("..\\Data\\Scripts\\PremiosLeilao\\%s.txt", fileName))
	DataBase.SetValue("Character", "LeilaoPremioRetirado", 0, "Name", Name)
	DataBase.SetString("Character", "LeilaoPremioCodigo", "nil", "Name", Name)
	SendMessage(string.format("[Leilao] Premio resgatado com sucesso!"), aIndex, 1)
	return
end

function Leilao.ConverterString(str)
   local result = {}
   load(str, '', 't', setmetatable({}, {
      __index = function(t,k) return k end,
      __newindex = result
   }))()
   return result
end

function Leilao.GerarNome(tamanho)
	local nome = ""
	for i = 1, tamanho do
		nome = nome .. string.char(math.random(97, 122))
	end
	return nome
end

function Leilao.Clear()
	leilaoStarted = false
	leilaoStartedCommand = false
	leilaoAreaStarted = false
	leilaoStaff = nil
	leilaoGanhador = {_nome = "Nenhum Lance Registrado", _lance = 0, _indexPlayer = 0}
	leilaoConfig = {}
	leilaoAnnounceMinutes = nil
	leilaoMinutos = nil
	leilaoSegundos = nil
	timerMinutos = nil
	timerSegundos = nil
	timerAnnounce = nil
	leilaoPremio = nil
	leilaoLanceMinimo = nil
	leilaoMoeda = nil
	leilaoArea = nil
	Player = {}
	return
end

function Leilao.CheckArea(aIndex, map, x, y, sx, sy)
	if leilaoAreaStarted == false
	then
		return
	end
	
	local player = User.new(aIndex)
	
	if has_key(Player, player:getName())
	then
		if map ~= leilaoArea._map
		then
			SendMessage(string.format("[Sistema] voce saiu da area do Leilao"), aIndex, 1)
			RemoverTable(Player, player:getName())
			return
		end
		
		if sx < leilaoArea._x1 or sx > leilaoArea._x2 or sy < leilaoArea._y1 or sy > leilaoArea._y2
		then
			SendMessage(string.format("[Sistema] voce saiu da area do Leilao"), aIndex, 1)
			RemoverTable(Player, player:getName())
			return
		end
	else
		if map == leilaoArea._map and sx >= leilaoArea._x1 and sx <= leilaoArea._x2 and sy >= leilaoArea._y1 and sy <= leilaoArea._y2
		then
			SendMessage(string.format("[Sistema] voce entrou na area do Leilao"), aIndex, 1)
			SendMessage(string.format("use %s para dar um lance", LEILAO_BID_COMMAND), aIndex, 1)
			InsertKey(Player, player:getName())
			return
		end
	end

end

Leilao.Init()

return Leilao